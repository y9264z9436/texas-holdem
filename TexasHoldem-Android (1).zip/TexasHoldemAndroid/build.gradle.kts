// 顶层构建脚本：只声明插件版本，不在这里应用
plugins {
    id("com.android.application") version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "1.9.25" apply false
}
