# 德州扑克 · 单机版（Android）

一个**纯离线、零依赖、无网络权限**的 6 人桌德州扑克安卓 App 工程源码。
游戏逻辑用 JavaScript 写在 `assets/www` 里，外层是一个极简的 Kotlin WebView 壳。

> 只用虚拟筹码，不含任何充值、提现、投注功能。
>
> **关于联网**：支持 2–4 人联机对战。房间号模式需要访问 PeerJS 公共信令服务器（仅用于牵线），
> 配对成功后牌局数据是两台手机**点对点直连**的，不经过服务器。
> 所以 `AndroidManifest.xml` 现在申请了 INTERNET 权限；如果只想单机玩，删掉这条权限也不影响单机功能。

---

## 一、怎么编译成 APK

### 环境要求
| 项 | 版本 |
|---|---|
| Android Studio | Hedgehog (2023.1) 或更新 |
| JDK | 17（Android Studio 自带，用内置的即可） |
| Android SDK | compileSdk 34（首次打开会提示下载，点同意） |
| Gradle | 8.7（工程已带 wrapper，会自动下载） |

### 方式 A：Android Studio（推荐，最省事）
1. 解压本 zip。
2. Android Studio → `File` → `Open`，选中 `TexasHoldemAndroid` 目录（有 `settings.gradle.kts` 的那层）。
3. 等右下角 Gradle Sync 跑完（首次会下载 Gradle 8.7 和 AGP，约 5–10 分钟）。
4. 菜单 `Build` → `Build Bundle(s)/APK(s)` → `Build APK(s)`。
5. 完成后点弹窗里的 `locate`，APK 在这里：
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```
6. 把这个 APK 传到手机安装即可（需要允许"安装未知来源应用"）。

**想装到手机上直接点一下就装上**：用数据线连电脑，在 Android Studio 选好设备后按绿色 ▶ Run 按钮，会自动安装并启动。

### 方式 B：命令行（不用打开 IDE）
```bash
cd TexasHoldemAndroid
./gradlew assembleDebug          # macOS / Linux
gradlew.bat assembleDebug        # Windows
```
产物同样是 `app/build/outputs/apk/debug/app-debug.apk`。

> 注意：命令行构建要求 `JAVA_HOME` 指向 **JDK 17**。用 JDK 21 也基本没问题，但 **JDK 25 会失败**（AGP 8.6 不支持）。

### 方式 C：没有电脑？用 GitHub 云编译（手机就能完成）

工程里已经写好 `.github/workflows/build-apk.yml`，推到 GitHub 后由 GitHub 的服务器编译。
完整操作见下方「六、只有手机怎么办」。

### 出正式版（可选）
```bash
./gradlew assembleRelease
```
未配置签名时产物是 `app-release-unsigned.apk`，装不上手机。要么用
`Build → Generate Signed Bundle / APK` 走一遍向导生成签名，要么先用 debug 包玩。
release 的混淆开关目前是关的（`isMinifyEnabled = false`），确认能出包后再自行打开。

### 国内网络下载慢怎么办
Gradle 和 AGP 从 `services.gradle.org`、`dl.google.com` 下载，国内可能很慢。
两个办法：

1. **给 Gradle 挂镜像**：编辑 `gradle/wrapper/gradle-wrapper.properties`，把
   `distributionUrl` 换成腾讯云或阿里云的 Gradle 镜像地址。
2. **给依赖挂镜像**：在 `settings.gradle.kts` 的 `repositories` 里把
   `google()` / `mavenCentral()` 前面加上：
   ```kotlin
   maven { url = uri("https://maven.aliyun.com/repository/google") }
   maven { url = uri("https://maven.aliyun.com/repository/public") }
   ```

---

## 二、工程结构

```
TexasHoldemAndroid/
├── settings.gradle.kts               # 模块与仓库配置
├── build.gradle.kts                  # 插件版本（AGP 8.6.1 / Kotlin 1.9.25）
├── gradle.properties
├── gradlew / gradlew.bat             # 命令行构建脚本
├── gradle/wrapper/                   # Gradle 8.7 wrapper（jar 已内置）
├── test/run-tests.js                 # Node 测试：牌型 + 筹码守恒
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml       # 含 INTERNET 权限（联机用）
        ├── java/com/xiongda/texasholdem/
        │   ├── MainActivity.kt       # WebView 壳（WebViewAssetLoader 提供 https 源）
        │   ├── Lan.kt               # 局域网直连：原生 TCP 服务端/客户端
        │   └── LanBridge.kt         # 暴露给网页的 window.LanBridge 接口
        ├── assets/www/               # ★ 游戏本体，纯前端
        │   ├── index.html
        │   ├── css/style.css
        │   └── js/
        │       ├── poker.js          # 牌、洗牌、7 选 5 牌型判定
        │       ├── ai.js            # 蒙特卡洛胜率 + 底池赔率 + 性格因子 + 难度
        │       ├── net.js           # 联机传输：房间号(PeerJS) / 连接码(WebRTC)
        │       ├── vendor/          # PeerJS 库（已内联，不需要外部下载）
        │       ├── engine.js        # 状态机：发牌/下注轮/边池结算
        │       └── ui.js            # 渲染与交互
        └── res/
            ├── values/              # 文案、主题、颜色
            ├── xml/                 # 备份规则
            └── mipmap-*/            # 启动图标（已生成全尺寸 PNG）
```

---

## 三、玩法说明

### 单机
- **6 人桌**：你 + 5 个 AI，每个 AI 有独立性格（紧凶 / 松凶 / 岩石 / 均衡 / 疯子）
- **三档 AI 难度**：简单 / 普通 / 困难（影响 AI 的算力、误差和松紧）

### 联机（2–4 人）

**三种连接方式，按需选：**

| 方式 | 需要什么 | 适用 |
|---|---|---|
| **局域网直连**（推荐，仅 APP） | 同一个 WiFi | 免服务器，房主开启后显示 IP，对方输最后一段数字即进 |
| **房间号** | 能访问 PeerJS 公共服务器 | 网页版 / 跨网络 |
| **连接码** | 都不需要 | 前两种都不通时兜底 |

- **局域网直连**：原生 TCP 实现，房主开端口、对方直连，数据不经过任何外部服务器；网页版用不了（浏览器不能监听端口）
- **房间号进房**：房主建房得到一个 4 位数字，其他人输号即进
- **备选连接码模式**：连不上信令服务器时用，一个框一个按钮，点两下就能连
- **自定义昵称**：进房前填，显示在座位、聊天、结算里
- **房间聊天**：左下角半透明消息区，显示 8 秒自动收起
- **掉线保护**：玩家掉线自动弃牌、超时自动弃牌、房主离开会通知所有人
- **无限注**：弃牌、过牌、跟注、加注、全下，支持加注滑杆与 ½池 / ¾池 / 1池 / 全下快捷键
- **完整边池**：不同筹码量全下时按标准规则分层结算，多余下注自动退还
- **AI 决策**：翻前用起手牌强度表 + 人数折价；翻后用蒙特卡洛模拟算胜率，再和底池赔率比较，叠加性格系数
- **实时牌型提示**：自己的牌会显示当前成牌名称（如"两对""同花听牌"）
- **战绩**：手数、单局最大赢池存在本地，卸载或清数据才会丢

---

## 四、想改点什么

| 想改 | 改哪里 |
|---|---|
| 初始筹码 2000 | `app/src/main/assets/www/js/ui.js` 里 `new window.Engine({ startChips: 2000 })` |
| 盲注 10/20 | 同上 `blinds: [10, 20]` |
| AI 的名字、头像、性格 | `engine.js` 顶部的 `DEFAULT_PERSONAS`（`aggr` 越大越凶、`tight` 越大越紧、`bluff` 是诈唬率） |
| AI 思考速度 | `ui.js` 里的 `SPEEDS = [420, 780, 1250]`，单位毫秒 |
| 改成 9 人桌 | `DEFAULT_PERSONAS` 加 3 个对象，并同步 `ui.js` 的 `SEAT_POS` 坐标 |
| 配色 | `css/style.css` 顶部 `:root` 的 CSS 变量 |
| 应用名 / 包名 | `res/values/strings.xml` 的 `app_name`；包名要改 `build.gradle.kts` 的 `applicationId` + `namespace` 和 `MainActivity.kt` 的包声明，并同步移动目录 |

改完 JS 不用重新编译 Kotlin，直接 `./gradlew assembleDebug` 出包。

---

## 五、这份代码验证到什么程度（说清楚）

**已用 Node 实测通过**（`node test/run-tests.js`，24 项断言全过）：

- 11 种牌型判定：皇家同花顺、同花顺、四条、葫芦、同花、顺子（含 A2345 轮子）、三条、两对、一对、高牌
- 牌型大小与踢脚比较、平局判定
- 胜率合理性：AA 单挑 85.8%、72o 34.2%、AA 六人桌 49.1%（与理论值吻合）
- **400 手完整对局自动对战**：无异常、无死循环、每手结束筹码总量守恒
- **1000 次全员全下跑马**：筹码守恒、边池分配正常

**界面层也用 jsdom 真跑过**（`test/ui-test.js`）：在无头 DOM 里连续打了 20 手，
自动点击「跟注 / 加注 / 弃牌 / 下一手」，检查每手的座位数、手牌张数、筹码与底池渲染，
结果：摊牌 13 手、提前结束 7 手，**零运行时异常**，菜单抽屉、速度切换也正常。

**没有做到的**：本环境没有 Android SDK，**APK 未经真机编译验证**。
代码层面能保证的：工程零第三方依赖、单 Activity、无反射、无 JNI，属于最容易编译通过的那类工程。
如果 Gradle 报错，把报错贴给我，我按错误信息改。

---

## 六、只有手机怎么办（GitHub Actions 云编译）

不需要电脑。GitHub 提供免费的编译服务器，你只要把工程传上去，它替你编译出 APK。

### 第 0 步：准备工作
- 一个 GitHub 账号（`github.com` 注册，需要邮箱验证）
- 手机上把浏览器切到「桌面版网站」模式（Chrome / Safari 都有这个选项），网页功能更全

### 第 1 步：建仓库
1. 打开 `github.com`，登录
2. 右上角 `+` → `New repository`
3. Repository name 随便填，比如 `texas-holdem`
4. 选 **Public**（公开仓库用 Actions 不消耗流量额度）
5. 勾上 `Add a README file`，点 `Create repository`

### 第 2 步：上传源码压缩包
1. 在仓库首页点 `Add file` → `Upload files`
2. 把 `TexasHoldem-Android.zip` 传上去（**注意：传 zip 本身，不用解压**）
3. 底部点 `Commit changes`

### 第 3 步：添加编译配置
> 顺序很重要：**先传 zip，再加配置文件**，因为加配置这个动作本身会触发一次编译。

1. 仓库首页点 `Add file` → `Create new file`
2. 文件名那一栏直接输入：`.github/workflows/build-apk.yml`
   （输入 `/` 会自动建出多级目录，放心打）
3. 把仓库里 `TexasHoldemAndroid/.github/workflows/build-apk.yml` 的内容整个复制进去
   —— 或者更省事：点 `Add file` → `Upload files`，把 `.github/workflows/build-apk.yml` 一起拖上去（手机上传单个文件保留不了目录时，就用上面「Create new file」的办法）
4. 底部 `Commit changes`

### 第 4 步：等它编译
1. 仓库顶部点 `Actions` 标签
2. 会看到一个正在跑的任务（黄色圆点在转），点进去
3. 大约 **3–6 分钟**，变成绿色对勾就是成功
4. 红叉就是失败，点进去看哪一步红了，把红字发我

### 第 5 步：下载并安装 APK
编译成功后有两种拿包方式，**推荐第二种**：

- **方式一（免解压）**：仓库首页右侧 `Releases` → 点最新的 `build-N` → 点里面的 `app-debug.apk` 直接下载
- **方式二**：`Actions` → 点进那次成功的运行 → 页面底部 `Artifacts` → 下载 `TexasHoldem-debug-apk.zip`，再用手机文件管理器解压出 APK

下载完点开安装，系统提示「未知来源」时去设置里允许一次即可。

### 常见问题
| 现象 | 原因 / 处理 |
|---|---|
| Actions 页面是空的 | 配置文件路径不对，必须是 `.github/workflows/xxx.yml`（注意最前面的点） |
| 报 `仓库根目录没找到 zip 文件` | zip 没传到仓库**根目录**，或者文件名不叫 `*.zip` |
| 报 `Permission denied` 于 gradlew | 工作流里已做 `chmod +x`，若仍报错说明压缩包里的 gradlew 权限丢了，重新上传 zip 即可 |
| 编译报 JDK 版本错误 | 工作流已固定 JDK 17，若报错请检查是否被人改过 `setup-java` 那段 |
| 国内打开 github.com 很慢 | 换个时段再试，或用手机流量/切换网络；这一步只影响操作体验，不影响编译 |
| 想改游戏内容 | 改完重新打 zip 上传，Actions 会自动再编一次 |

> 说明：公开仓库的 Actions 完全免费；私有仓库每月有 2000 分钟免费额度，我们这个工程一次编译约 4 分钟，也够用几十次。

---

## 七、常用链接速查

以下地址均已实测可访问（2026-11 验证）。

### Gradle 官方
| 用途 | 地址 |
|---|---|
| 官网首页 | https://gradle.org |
| 所有版本下载页 | https://gradle.org/releases/ |
| 下载文件直连目录 | https://services.gradle.org/distributions/ |
| 插件仓库 | https://plugins.gradle.org |
| 本文用到的 8.7 版本文档 | https://docs.gradle.org/8.7/release-notes.html |
| 官方文档总入口 | https://docs.gradle.org |

### Gradle 8.7 下载地址（本工程用的版本）
| 来源 | 地址 | 大小 |
|---|---|---|
| **腾讯云镜像**（国内首选） | `https://mirrors.cloud.tencent.com/gradle/gradle-8.7-bin.zip` | 134,184,980 字节 |
| **华为云镜像** | `https://mirrors.huaweicloud.com/gradle/gradle-8.7-bin.zip` | 同上 |
| 官方 | `https://services.gradle.org/distributions/gradle-8.7-bin.zip` | 同上 |
| 完整版（含源码与文档，一般不需要） | `https://mirrors.cloud.tencent.com/gradle/gradle-8.7-all.zip` | 224,435,312 字节 |

**校验值（bin 包）**
```
SHA-256: 544c35d6bd849ae8a5ed0bcea39ba677dc40f49df7d1835561582da2009b961d
```
- Windows：`certutil -hashfile gradle-8.7-bin.zip SHA256`
- macOS / Linux：`shasum -a 256 gradle-8.7-bin.zip`

> 实测无效、不用试：阿里云 `mirrors.aliyun.com/gradle/`（404）、清华 TUNA（404）、中科大（403）。
> 国内 Gradle 镜像实际只有腾讯云和华为云两家可用。

### 怎么把工程切到镜像
改 `gradle/wrapper/gradle-wrapper.properties`：
```properties
distributionUrl=https\://mirrors.cloud.tencent.com/gradle/gradle-8.7-bin.zip
```
注意 `https\:` 里那个**反斜杠**是 properties 的转义写法，别删。
改完点 `File → Sync Project with Gradle Files`。

### 阿里巴巴 Maven 镜像（解决依赖下载卡住）
在 `settings.gradle.kts` 的两个 `repositories {}` 块里，加到 `google()` / `mavenCentral()` 前面：
```kotlin
maven { url = uri("https://maven.aliyun.com/repository/google") }
maven { url = uri("https://maven.aliyun.com/repository/public") }
maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
```

### 其他
| 用途 | 地址 |
|---|---|
| Android Studio 下载 | https://developer.android.com/studio |
| Android SDK 命令行工具 | https://developer.android.com/studio#command-tools |
| Android 官方文档 | https://developer.android.com/docs |
| GitHub Actions 文档 | https://docs.github.com/actions |
| GitHub Actions 官方 Android 构建示例 | https://github.com/actions/starter-workflows |

---

## 八、合规提醒

德州扑克在国内属于敏感品类（2018 年起德州类网络游戏被要求下架且停止备案受理）。
本工程是**纯单机、虚拟筹码、无充值、无联网**的练习/娱乐软件，不涉及真钱输赢。
请勿在此基础上加入充值、提现、房卡开房、多人联网对战或任何形式的筹码变现功能——那会让它变成赌博工具，性质完全不同。
