/* 用 jsdom 真跑界面层：连续打若干手，检查运行时异常与渲染结果 */
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const WWW = '/sandbox/workspace/TexasHoldemAndroid/app/src/main/assets/www/index.html';

const errors = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => errors.push('jsdomError: ' + (e.message || e)));

const pending = [];

(async () => {
  const dom = await JSDOM.fromFile(WWW, {
    runScripts: 'dangerously',
    resources: 'usable',
    pretendToBeVisual: true,
    virtualConsole: vc,
    beforeParse(window) {
      // 把 setTimeout 变成手动队列，让 AI 立即行动，避免真实等待
      window.setTimeout = function (fn) { pending.push(fn); return 0; };
      window.clearTimeout = function () { };
      window.addEventListener('error', ev => errors.push('window.error: ' + ev.message));
    }
  });

  const win = dom.window;
  const doc = win.document;
  const $ = id => doc.getElementById(id);

  await new Promise(r => setTimeout(r, 600));   // 等待脚本加载
  if (!win.Engine || !win.Poker) { console.log('✗ 脚本未加载'); process.exit(1); }

  function drain(limit = 4000) {
    let n = 0;
    while (pending.length && n++ < limit) {
      const f = pending.shift();
      try { f(); } catch (e) { errors.push('timer: ' + e.message + ' | ' + (e.stack || '').split('\n')[1]); break; }
    }
  }

  const hands = 20;
  let played = 0, showdown = 0, foldEnd = 0;
  let heroWins = 0;

  for (let h = 0; h < hands; h++) {
    let guard = 0;
    while (guard++ < 600) {
      drain();
      if (!$('nextRow').classList.contains('hidden')) break;
      if (!$('btnRow').classList.contains('hidden')) {
        const r = Math.random();
        const btn = r < 0.62 ? $('btnCall') : (r < 0.88 ? $('btnRaise') : $('btnFold'));
        btn.dispatchEvent(new win.Event('click'));
        continue;
      }
      // 既不是英雄回合也没结束：说明 AI 队列空了，防止死循环
      break;
    }
    if (!$('nextRow').classList.contains('hidden')) {
      played++;
      const banner = $('banner').innerHTML;
      if (banner.includes('赢家')) showdown++; else foldEnd++;
      if (banner.includes('你赢得')) heroWins++;

      // 检查渲染一致性
      const pot = Number($('potVal').textContent.replace(/[^\d.]/g, '')) || 0;
      const seats = doc.querySelectorAll('#seats .seat').length;
      if (seats !== 5) errors.push(`第${h}手：座位数 ${seats}，应为 5`);
      const heroCards = doc.querySelectorAll('#heroCards .card').length;
      if (heroCards !== 2) errors.push(`第${h}手：自己手牌 ${heroCards} 张，应为 2`);
      const chips = [...doc.querySelectorAll('#seats .seat .chips')].map(e => e.textContent);
      if (chips.some(c => c === '' || c === 'NaN' || c === 'undefined')) errors.push(`第${h}手：筹码显示异常 ${chips}`);
      if ($('potVal').textContent.includes('NaN')) errors.push(`第${h}手：底池 NaN`);
    }
    // 下一手
    $('btnNext').dispatchEvent(new win.Event('click'));
    drain();
  }

  // 额外检查：加注滑杆、快捷按钮、菜单
  $('btnMenu').dispatchEvent(new win.Event('click'));
  const drawerOpen = !$('drawer').classList.contains('hidden');
  $('btnSpeed').dispatchEvent(new win.Event('click'));
  $('btnCloseDrawer').dispatchEvent(new win.Event('click'));

  console.log(`打了 ${played}/${hands} 手：摊牌结束 ${showdown}，提前结束 ${foldEnd}，你赢 ${heroWins} 手`);
  console.log(`抽屉可打开：${drawerOpen}`);
  if (errors.length) {
    console.log('✗ 运行时问题：');
    [...new Set(errors)].slice(0, 15).forEach(e => console.log('   ', e));
    process.exit(1);
  } else {
    console.log('✓ 界面层无运行时异常（渲染、结算、下一手、菜单均正常）');
  }
  process.exit(0);
})();
