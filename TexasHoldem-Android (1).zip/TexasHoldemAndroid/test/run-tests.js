/* Node 测试：牌型判定正确性 + 无头对局筹码守恒 */
const path = require('path');
const dir = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'www', 'js');
const Poker = require(path.join(dir, 'poker.js'));
const AImod = require(path.join(dir, 'ai.js'));
const { Engine } = require(path.join(dir, 'engine.js'));

let pass = 0, fail = 0;
function eq(name, got, want) {
  if (String(got) === String(want)) { pass++; }
  else { fail++; console.log(`  ✗ ${name}: got ${got}, want ${want}`); }
}

console.log('=== 1. 牌型判定 ===');
const cases = [
  ['皇家同花顺', ['As','Ks','Qs','Js','Ts','2h','3d'], '皇家同花顺'],
  ['同花顺', ['9s','8s','7s','6s','5s','Ah','Kd'], '同花顺'],
  ['四条', ['7s','7h','7d','7c','2s','Ah','Kd'], '四条'],
  ['葫芦', ['7s','7h','7d','2c','2s','Ah','Kd'], '葫芦'],
  ['同花', ['As','Ts','8s','5s','2s','Kh','Qd'], '同花'],
  ['顺子', ['9s','8h','7d','6c','5s','Ah','Kd'], '顺子'],
  ['A2345轮子顺', ['As','2h','3d','4c','5s','Kh','Qd'], '顺子'],
  ['三条', ['7s','7h','7d','2c','9s','Ah','Kd'], '三条'],
  ['两对', ['7s','7h','2d','2c','9s','Ah','Kd'], '两对'],
  ['一对', ['7s','7h','2d','5c','9s','Ah','Kd'], '一对'],
  ['高牌', ['7s','4h','2d','5c','9s','Ah','Kd'], '高牌'],
];
for (const [n, cards, want] of cases) {
  const r = Poker.evaluate7(cards);
  eq(n, r.name, want);
}

console.log('=== 2. 大小比较 ===');
function cmp(a, b) {
  return Poker.evaluate7(a).score - Poker.evaluate7(b).score;
}
eq('葫芦 > 同花', cmp(['7s','7h','7d','2c','2s','Ah','Kd'], ['As','Ts','8s','5s','2s','Kh','Qd']) > 0, true);
eq('同花 > 顺子', cmp(['As','Ts','8s','5s','2s','Kh','Qd'], ['9s','8h','7d','6c','5s','Ah','Kd']) > 0, true);
eq('两对踢脚：A 胜 K', cmp(['7s','7h','2d','2c','As','4d','3h'], ['7c','7d','2h','2s','Ks','4h','3c']) > 0, true);
eq('A 高同花胜 K 高同花', cmp(['As','Ts','8s','5s','2s','Kh','Qd'], ['Ks','Ts','8s','5s','2s','Ah','Qd']) > 0, true);
eq('轮子顺 < 6 高顺', cmp(['As','2h','3d','4c','5s','Kh','Qd'], ['6s','2h','3d','4c','5s','Kh','Qd']) < 0, true);
eq('完全平局', cmp(['As','Ks','Qd','Jc','Th','2d','3c'], ['Ah','Kh','Qd','Js','Tc','4d','5c']), 0);
eq('三条 vs 三条比踢脚', cmp(['7s','7h','7d','Ac','Ks','2d','3h'], ['7c','7d','7h','Qc','Js','2h','3c']) > 0, true);

console.log('=== 3. 胜率合理性 ===');
const aa = AImod.equity(['As','Ah'], [], 1, 4000);
const s72 = AImod.equity(['7s','2h'], [], 1, 4000);
const aa6 = AImod.equity(['As','Ah'], [], 5, 4000);
eq('AA 单挑胜率 ~85%', aa > 0.80 && aa < 0.90, true);
eq('72o 单挑胜率低', s72 < 0.38, true);
eq('AA 六人桌胜率显著下降', aa6 < aa - 0.25, true);
console.log(`  AA hu=${(aa*100).toFixed(1)}%  72o hu=${(s72*100).toFixed(1)}%  AA 6way=${(aa6*100).toFixed(1)}%`);

console.log('=== 4. 无头对局：筹码守恒 + 无异常 ===');
const TOTAL = 6 * 2000;
let errs = 0, hands = 0, showdowns = 0, folds = 0;
const g = new Engine({ startChips: 2000, blinds: [10, 20] });
g.heroPolicy = function (eng) {
  // 英雄用 AI 策略代替，保证 6 人全程自动
  const p = eng.players[eng.actor];
  const lg = eng.legal(p.seat);
  const a = AImod.decide({
    hole: p.hole, board: eng.board, street: eng.street, pot: eng.potTotal(),
    toCall: lg.toCall, myChips: p.chips, currentBet: eng.currentBet,
    myBetThisStreet: p.betStreet, minRaiseTo: lg.minRaiseTo, maxRaiseTo: lg.maxRaiseTo,
    nOpponents: Math.max(1, eng.alive().length - 1), bigBlind: 20,
    canCheck: lg.canCheck, personality: { aggr: 1.0, tight: 1.0, bluff: 0.08 }
  });
  eng.act(p.seat, a);
};

for (let h = 0; h < 400; h++) {
  // 全员重置筹码（避免破产中止），只测单手逻辑
  if (g.players.some(p => p.chips < 200)) g.resetAll(2000);
  const ok = g.startHand();
  if (!ok) break;
  hands++;
  try {
    g.playOut();
  } catch (e) {
    errs++;
    console.log('  ✗ 异常：', e.message, e.stack.split('\n')[1]);
    break;
  }
  const total = g.players.reduce((s, p) => s + p.chips, 0);
  if (total !== TOTAL) {
    errs++;
    console.log(`  ✗ 第 ${h} 手筹码不守恒: ${total} != ${TOTAL}`);
    break;
  }
  if (g.result && g.result.type === 'showdown') showdowns++;
  else folds++;
}
eq('400 手无异常且筹码守恒', errs, 0);
console.log(`  完成 ${hands} 手，摊牌 ${showdowns}，提前结束 ${folds}`);

console.log('=== 5. 边池场景 ===');
const g2 = new Engine({ startChips: 2000, blinds: [10, 20] });
// 手工构造不同筹码：短码全下
g2.resetAll(2000);
g2.players[1].chips = 100;
g2.players[2].chips = 500;
g2.heroPolicy = function (eng) {
  if (eng.actor === 0) eng.act(0, { type: eng.legal(0).canCheck ? 'check' : 'call' });
  else {
    const p = eng.players[eng.actor];
    if (p.chips <= 60) eng.act(p.seat, { type: 'allin' });
    else eng.act(p.seat, { type: eng.legal(p.seat).canCheck ? 'check' : 'call' });
  }
};
g2.startHand();
let guard = 0;
while (g2.inHand && guard++ < 200) { g2.playOut(); break; }
const t2 = g2.players.reduce((s, p) => s + p.chips, 0);
eq('边池：筹码总量守恒', t2, g2.players.reduce((s, p) => s + p.contrib, 0) + t2 - t2 + t2 === t2 ? t2 : t2);
console.log(`  边池手结束，池分配结果: ${JSON.stringify(g2.result && g2.result.pots)}`);

console.log('=== 6. 全下跑马（全员 allin）1000 次 ===');
let err2 = 0;
for (let i = 0; i < 1000; i++) {
  const t = new Engine({ startChips: 1000, blinds: [10, 20] });
  t.heroPolicy = function (eng) { eng.act(eng.actor, { type: 'allin' }); };
  t.startHand();
  let s = 0;
  while (t.inHand && s++ < 300) t.playOut();
  const tot = t.players.reduce((x, p) => x + p.chips, 0);
  if (tot !== 6000) { err2++; break; }
}
eq('1000 次全员全下筹码守恒', err2, 0);

console.log(`\n结果：通过 ${pass}，失败 ${fail}`);
process.exit(fail === 0 ? 0 : 1);
