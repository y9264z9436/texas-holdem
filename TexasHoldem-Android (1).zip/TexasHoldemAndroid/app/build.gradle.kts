plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xiongda.texasholdem"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.xiongda.texasholdem"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            // 首次构建先关混淆，确认能出包后再自行打开
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    // 纯离线游戏：不产生任何网络资源，也不需要额外依赖
    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }
}

dependencies {
    // 只为一个目的：WebViewAssetLoader —— 把本地资源映射成 https 源，
    // 否则 WebRTC（联机对战）在 file:// 下会被判定为非安全上下文而失败。
    implementation("androidx.webkit:webkit:1.11.0")
}
