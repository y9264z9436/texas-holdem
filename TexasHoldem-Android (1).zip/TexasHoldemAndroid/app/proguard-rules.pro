# 没有使用 @JavascriptInterface 反射，保留默认规则即可
-keep class com.xiongda.texasholdem.MainActivity { *; }
