/* ==========================================================
 * engine.js —— 游戏状态机（纯逻辑，无 DOM 依赖）
 * 6 人桌 / 无限注德州 / 支持边池
 * ========================================================== */
(function (global) {
  'use strict';

  var Poker = global.Poker || (typeof require !== 'undefined' ? require('./poker.js') : null);
  var AI = global.AI || (typeof require !== 'undefined' ? require('./ai.js') : null);

  var STREETS = ['preflop', 'flop', 'turn', 'river'];
  var STREET_CN = { preflop: '翻前', flop: '翻牌', turn: '转牌', river: '河牌' };

  var DEFAULT_PERSONAS = [
    { name: '你',     aggr: 1.0, tight: 1.0,  bluff: 0.08, avatar: '🙂', tag: '玩家' },
    { name: '铁面',   aggr: 0.80, tight: 1.30, bluff: 0.04, avatar: '🕶️', tag: '紧凶' },
    { name: '小刀',   aggr: 1.35, tight: 0.85, bluff: 0.16, avatar: '🔪', tag: '松凶' },
    { name: '老张',   aggr: 0.55, tight: 1.45, bluff: 0.02, avatar: '🧔', tag: '岩石' },
    { name: '林小姐', aggr: 1.05, tight: 0.95, bluff: 0.10, avatar: '👩', tag: '均衡' },
    { name: '阿虎',   aggr: 1.60, tight: 0.70, bluff: 0.22, avatar: '🐯', tag: '疯子' }
  ];

  function Engine(opts) {
    opts = opts || {};
    this.blinds = opts.blinds || [10, 20];
    this.startChips = opts.startChips || 2000;
    this.personas = opts.personas || DEFAULT_PERSONAS;
    this.seatCount = this.personas.length;
    this.handNo = 0;
    this.dealer = -1;
    this.listeners = {};
    this.log = [];
    this.players = [];
    this.board = [];
    this.street = 'idle';
    this.resetAll(this.startChips);
    this.inHand = false;
  }

  Engine.prototype.on = function (evt, fn) {
    (this.listeners[evt] = this.listeners[evt] || []).push(fn);
    return this;
  };
  Engine.prototype.emit = function (evt, payload) {
    var arr = this.listeners[evt] || [];
    for (var i = 0; i < arr.length; i++) arr[i](payload, this);
  };
  Engine.prototype.addLog = function (text) {
    this.log.push(text);
    if (this.log.length > 200) this.log.shift();
    this.emit('log', text);
  };

  Engine.prototype.resetAll = function (chips, keepDealer) {
    var d = this.dealer;
    this.players = [];
    for (var i = 0; i < this.seatCount; i++) {
      var ps = this.personas[i];
      this.players.push({
        seat: i,
        name: ps.name,
        avatar: ps.avatar,
        tag: ps.tag,
        isHero: i === 0,
        personality: { aggr: ps.aggr, tight: ps.tight, bluff: ps.bluff },
        chips: chips,
        hole: [],
        folded: false,
        allin: false,
        betStreet: 0,
        contrib: 0,
        lastAction: '',
        showdownHand: null,
        wonLast: 0
      });
    }
    this.board = [];
    this.street = 'idle';
    this.currentBet = 0;
    this.minRaise = this.blinds[1];
    this.actor = -1;
    this.hasActed = {};
    this.handNo = 0;
    this.inHand = false;
    this.dealer = keepDealer ? d : -1;
    this.log = [];
    this.result = null;
  };

  /* ---------- 基础查询 ---------- */
  Engine.prototype.alive = function () {
    return this.players.filter(function (p) { return !p.folded && p.inHand; });
  };
  Engine.prototype.actable = function () {
    return this.players.filter(function (p) { return !p.folded && p.inHand && !p.allin && p.chips > 0; });
  };
  Engine.prototype.potTotal = function () {
    var s = 0;
    for (var i = 0; i < this.players.length; i++) s += this.players[i].contrib;
    return s;
  };
  Engine.prototype.nextIndex = function (from, filter) {
    for (var k = 1; k <= this.seatCount; k++) {
      var i = (from + k) % this.seatCount;
      if (filter(this.players[i])) return i;
    }
    return -1;
  };

  /* ---------- 开新一手 ---------- */
  Engine.prototype.startHand = function () {
    // 清场状态
    var i, p;
    for (i = 0; i < this.players.length; i++) {
      p = this.players[i];
      p.hole = []; p.folded = false; p.allin = false;
      p.betStreet = 0; p.contrib = 0; p.lastAction = '';
      p.showdownHand = null; p.wonLast = 0;
      p.inHand = p.chips > 0;
    }
    var funded = this.players.filter(function (x) { return x.inHand; });
    if (funded.length < 2) {
      this.addLog('筹码不足，无法开局');
      this.emit('state');
      return false;
    }

    this.handNo++;
    this.board = [];
    this.street = 'preflop';
    this.currentBet = 0;
    this.minRaise = this.blinds[1];
    this.hasActed = {};
    this.result = null;
    this.inHand = true;

    // 移动庄家
    do { this.dealer = (this.dealer + 1) % this.seatCount; }
    while (!this.players[this.dealer].inHand);

    var deck = Poker.shuffle(Poker.makeDeck());
    var self = this;

    // 盲注
    var sbSeat, bbSeat;
    if (funded.length === 2) {
      sbSeat = this.dealer;
      bbSeat = this.nextIndex(this.dealer, function (x) { return x.inHand; });
    } else {
      sbSeat = this.nextIndex(this.dealer, function (x) { return x.inHand; });
      bbSeat = this.nextIndex(sbSeat, function (x) { return x.inHand; });
    }
    this.sbSeat = sbSeat; this.bbSeat = bbSeat;

    this.postBlind(sbSeat, this.blinds[0], '小盲');
    this.postBlind(bbSeat, this.blinds[1], '大盲');
    this.currentBet = Math.max(this.players[sbSeat].betStreet, this.players[bbSeat].betStreet);
    this.minRaise = this.blinds[1];

    // 发底牌
    for (i = 0; i < 2; i++) {
      var s = this.dealer;
      for (var n = 0; n < funded.length; n++) {
        s = this.nextIndex(s, function (x) { return x.inHand; });
        this.players[s].hole.push(deck.pop());
      }
    }
    this.deck = deck;

    this.addLog('—— 第 ' + this.handNo + ' 手 · 庄家 ' + this.players[this.dealer].name + ' ——');

    // 翻前首个行动者：大盲下家
    var first = this.nextIndex(bbSeat, function (x) { return x.inHand && !x.allin; });
    if (first < 0) first = this.nextIndex(bbSeat, function (x) { return x.inHand; });
    this.actor = first;
    this.emit('handStart');
    this.emit('state');
    return true;
  };

  Engine.prototype.postBlind = function (seat, amount, label) {
    var p = this.players[seat];
    var pay = Math.min(amount, p.chips);
    p.chips -= pay; p.betStreet += pay; p.contrib += pay;
    if (p.chips === 0) p.allin = true;
    p.lastAction = label + ' ' + pay;
    this.addLog(p.name + ' 下' + label + ' ' + pay);
  };

  /* ---------- 合法动作 ---------- */
  Engine.prototype.legal = function (seat) {
    var p = this.players[seat];
    var toCall = Math.min(this.currentBet - p.betStreet, p.chips);
    var canCheck = toCall <= 0;
    var maxRaiseTo = p.betStreet + p.chips;
    var minRaiseTo = Math.min(this.currentBet + this.minRaise, maxRaiseTo);
    return {
      toCall: toCall,
      canCheck: canCheck,
      canRaise: maxRaiseTo > this.currentBet && p.chips > toCall,
      minRaiseTo: minRaiseTo,
      maxRaiseTo: maxRaiseTo,
      pot: this.potTotal()
    };
  };

  /* ---------- 执行动作 ---------- */
  Engine.prototype.act = function (seat, action) {
    var p = this.players[seat];
    if (!p || p.folded || p.allin) return false;
    var lg = this.legal(seat);
    var type = action.type;
    var self = this;

    if (type === 'fold') {
      p.folded = true;
      p.lastAction = '弃牌';
      this.addLog(p.name + ' 弃牌');
    } else if (type === 'check') {
      if (!lg.canCheck) return this.act(seat, { type: 'call' });
      p.lastAction = '过牌';
      this.addLog(p.name + ' 过牌');
    } else if (type === 'call') {
      var pay = lg.toCall;
      if (pay > 0) {
        p.chips -= pay; p.betStreet += pay; p.contrib += pay;
        if (p.chips === 0) p.allin = true;
      }
      p.lastAction = (lg.canCheck ? '过牌' : '跟注 ' + pay) + (p.allin ? '（全下）' : '');
      this.addLog(p.name + (lg.canCheck ? ' 过牌' : ' 跟注 ' + pay) + (p.allin ? '，全下' : ''));
    } else if (type === 'raise') {
      var to = Math.round(action.amount || 0);
      if (to < lg.minRaiseTo) to = lg.minRaiseTo;
      if (to > lg.maxRaiseTo) to = lg.maxRaiseTo;
      var delta = to - p.betStreet;
      if (delta <= 0) return this.act(seat, { type: 'call' });
      var isRaise = this.currentBet > 0;
      var raiseAmount = to - this.currentBet;
      p.chips -= delta; p.betStreet = to; p.contrib += delta;
      if (p.chips === 0) p.allin = true;
      if (to > this.currentBet) {
        this.minRaise = Math.max(this.minRaise, raiseAmount);
        this.currentBet = to;
        this.hasActed = {}; // 被加注后所有人重新获得行动权
      }
      p.lastAction = (isRaise ? '加注到 ' : '下注 ') + to + (p.allin ? '（全下）' : '');
      this.addLog(p.name + ' ' + (isRaise ? '加注到 ' : '下注 ') + to + (p.allin ? '，全下' : ''));
    } else if (type === 'allin') {
      var allTo = p.betStreet + p.chips;
      if (allTo <= this.currentBet) {
        // 不足跟注，视为跟注全下
        var pay2 = p.chips;
        p.chips = 0; p.betStreet += pay2; p.contrib += pay2; p.allin = true;
        p.lastAction = '全下 ' + p.betStreet;
        this.addLog(p.name + ' 全下 ' + p.betStreet);
      } else {
        var delta2 = p.chips;
        var raiseAmt = allTo - this.currentBet;
        p.chips = 0; p.betStreet = allTo; p.contrib += delta2; p.allin = true;
        if (allTo > this.currentBet) {
          this.minRaise = Math.max(this.minRaise, raiseAmt);
          this.currentBet = allTo;
          this.hasActed = {};
        }
        p.lastAction = '全下 ' + allTo;
        this.addLog(p.name + ' 全下 ' + allTo);
      }
    } else {
      return false;
    }

    this.hasActed[seat] = true;
    this.emit('action', { seat: seat, action: action });
    this.advance();
    return true;
  };

  /* ---------- 推进流程 ---------- */
  Engine.prototype.advance = function () {
    var aliveList = this.alive();
    if (aliveList.length === 1) {
      this.awardSingle(aliveList[0]);
      return;
    }
    var self = this;

    // 找到下一个需要行动的玩家
    var needs = this.players.filter(function (p) {
      if (!p.inHand || p.folded || p.allin || p.chips <= 0) return false;
      if (self.hasActed[p.seat] && p.betStreet >= self.currentBet) return false;
      if (p.betStreet >= self.currentBet && self.hasActed[p.seat]) return false;
      return true;
    });

    if (needs.length === 0) {
      this.endStreet();
      return;
    }

    // 从当前 actor 逆时针找第一个 needs 中的玩家
    var next = this.nextIndex(this.actor, function (p) {
      if (!p.inHand || p.folded || p.allin || p.chips <= 0) return false;
      return needs.indexOf(p) >= 0;
    });
    if (next < 0) next = needs[0].seat;
    this.actor = next;
    this.emit('state');
  };

  Engine.prototype.endStreet = function () {
    // 带走本街下注
    for (var i = 0; i < this.players.length; i++) this.players[i].betStreet = 0;
    this.currentBet = 0;
    this.minRaise = this.blinds[1];
    this.hasActed = {};

    var idx = STREETS.indexOf(this.street);
    if (idx >= STREETS.length - 1) {
      this.showdown();
      return;
    }
    this.street = STREETS[idx + 1];
    this.dealBoard();

    var act = this.actable();
    if (act.length <= 1) {
      // 全下状态，直接发完剩余公共牌
      while (this.street !== 'river') {
        this.street = STREETS[STREETS.indexOf(this.street) + 1];
        this.dealBoard();
      }
      this.showdown();
      return;
    }

    // 翻后首个行动者：庄家下家
    var first = this.nextIndex(this.dealer, function (p) {
      return p.inHand && !p.folded && !p.allin && p.chips > 0;
    });
    this.actor = first;
    this.emit('street', this.street);
    this.emit('state');
  };

  Engine.prototype.dealBoard = function () {
    if (this.street === 'flop') {
      this.board.push(this.deck.pop(), this.deck.pop(), this.deck.pop());
    } else if (this.street === 'turn' || this.street === 'river') {
      this.board.push(this.deck.pop());
    }
    this.addLog(STREET_CN[this.street] + '：' + this.board.map(function (c) {
      return Poker.rankLabel(Poker.rankOf(c)) + Poker.SUIT_SYMBOL[Poker.suitOf(c)];
    }).join(' '));
  };

  /* ---------- 结算 ---------- */
  Engine.prototype.awardSingle = function (winner) {
    var pot = this.potTotal();
    winner.chips += pot;
    winner.wonLast = pot;
    this.addLog(winner.name + ' 赢得底池 ' + pot + '（无人跟注）');
    this.result = {
      type: 'fold',
      winners: [winner.seat],
      pots: [{ amount: pot, winners: [winner.seat] }],
      hands: {}
    };
    this.emit('handEnd', this.result);
    this.inHand = false;
    this.street = 'idle';
    this.emit('state');
  };

  Engine.prototype.showdown = function () {
    var self = this;
    var aliveList = this.alive();
    var evals = {};
    aliveList.forEach(function (p) {
      var all = p.hole.concat(self.board);
      evals[p.seat] = all.length >= 5 ? Poker.evaluate7(all) : Poker.evaluate7(p.hole.concat(self.board));
      p.showdownHand = evals[p.seat];
    });

    // 边池分配
    var paid = this.players.map(function () { return 0; });
    var cum = 0;
    var potsOut = [];
    var guard = 0;
    while (guard++ < 50) {
      var level = Infinity;
      for (var i = 0; i < this.players.length; i++) {
        var remain = this.players[i].contrib - paid[i];
        if (remain > 0 && remain < level) level = remain;
      }
      if (!isFinite(level)) break;
      var potSize = 0;
      for (var j = 0; j < this.players.length; j++) {
        var take = Math.min(this.players[j].contrib - paid[j], level);
        potSize += take;
        paid[j] += take;
      }
      cum += level;
      var eligible = [];
      for (var k = 0; k < this.players.length; k++) {
        var p = this.players[k];
        if (!p.folded && p.inHand && p.contrib >= cum) eligible.push(p);
      }
      if (eligible.length === 0) {
        // 理论不该发生；兜底给第一个未弃牌者
        var fb = this.alive()[0];
        if (fb) { fb.chips += potSize; potsOut.push({ amount: potSize, winners: [fb.seat], label: '底池' }); }
        continue;
      }
      var hands = eligible.map(function (p) { return evals[p.seat]; });
      var winIdx = Poker.winners(hands);
      var share = Math.floor(potSize / winIdx.length);
      var rem = potSize - share * winIdx.length;
      var winSeats = [];
      for (var w = 0; w < winIdx.length; w++) {
        var pl = eligible[winIdx[w]];
        pl.chips += share + (w === 0 ? rem : 0);
        pl.wonLast += share + (w === 0 ? rem : 0);
        winSeats.push(pl.seat);
      }
      potsOut.push({ amount: potSize, winners: winSeats, label: potsOut.length === 0 ? '主池' : '边池' + potsOut.length });
    }

    var result = { type: 'showdown', pots: potsOut, hands: {}, board: this.board.slice() };
    aliveList.forEach(function (p) {
      result.hands[p.seat] = { name: p.showdownHand.name, hole: p.hole.slice(), cat: p.showdownHand.cat };
    });
    this.result = result;
    this.inHand = false;
    this.street = 'idle';
    this.emit('handEnd', result);
    this.emit('state');
  };

  /* ---------- AI 驱动 ---------- */
  Engine.prototype.actorIsHero = function () {
    return this.actor >= 0 && this.players[this.actor] && this.players[this.actor].isHero;
  };

  Engine.prototype.aiAct = function () {
    if (this.actor < 0) return false;
    var p = this.players[this.actor];
    if (p.isHero || p.folded || p.allin) return false;
    var lg = this.legal(p.seat);
    var nOpp = this.alive().length - 1;
    var action = AI.decide({
      hole: p.hole,
      board: this.board,
      street: this.street,
      pot: this.potTotal(),
      toCall: lg.toCall,
      myChips: p.chips,
      currentBet: this.currentBet,
      myBetThisStreet: p.betStreet,
      minRaiseTo: lg.minRaiseTo,
      maxRaiseTo: lg.maxRaiseTo,
      nOpponents: Math.max(1, nOpp),
      bigBlind: this.blinds[1],
      canCheck: lg.canCheck,
      difficulty: this.difficulty,
      personality: p.personality
    });
    return this.act(p.seat, action);
  };

  /* 切换 AI 难度（立即对后续每一次决策生效） */
  Engine.prototype.setDifficulty = function (level) {
    if (!level) return this.difficulty;
    this.difficulty = level;
    this.emit('difficulty', level);
    return this.difficulty;
  };

  /* 无头跑完一手（测试用 / AI 之间自动） */
  Engine.prototype.playOut = function (maxSteps) {
    var steps = 0;
    while (this.inHand && steps++ < (maxSteps || 2000)) {
      if (this.actor < 0) break;
      if (this.actorIsHero()) {
        // 测试模式：英雄交给指定策略
        if (this.heroPolicy) this.heroPolicy(this);
        else this.act(this.actor, { type: 'call' });
      } else {
        if (!this.aiAct()) break;
      }
    }
    return steps;
  };

  Engine.prototype.snapshot = function () {
    return {
      handNo: this.handNo,
      street: this.street,
      board: this.board.slice(),
      pot: this.potTotal(),
      currentBet: this.currentBet,
      minRaise: this.minRaise,
      dealer: this.dealer,
      actor: this.actor,
      result: this.result,
      players: this.players.map(function (p) {
        return {
          seat: p.seat, name: p.name, avatar: p.avatar, tag: p.tag, isHero: p.isHero,
          chips: p.chips, betStreet: p.betStreet, folded: p.folded, allin: p.allin,
          hole: p.hole.slice(), lastAction: p.lastAction,
          inHand: p.inHand, showdown: p.showdownHand ? p.showdownHand.name : null,
          wonLast: p.wonLast
        };
      })
    };
  };

  var API = { Engine: Engine, STREETS: STREETS, STREET_CN: STREET_CN, DEFAULT_PERSONAS: DEFAULT_PERSONAS };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  global.Engine = Engine;
  global.EngineAPI = API;
})(typeof window !== 'undefined' ? window : globalThis);
