/* ==========================================================
 * ai.js —— AI 决策：蒙特卡洛胜率 + 底池赔率 + 性格因子 + 难度
 * 纯逻辑，无 DOM 依赖，可被 Node 单测
 * ========================================================== */
(function (global) {
  'use strict';

  var Poker = global.Poker || (typeof require !== 'undefined' ? require('./poker.js') : null);
  var FULL_DECK = Poker.makeDeck();

  /* 三档难度：影响「算得准不准」「犯不犯错」「敢不敢跟」 */
  var DIFFICULTY = {
    easy: {
      label: '简单',
      noise: 0.16,     // 胜率估算误差（越大越容易误判）
      random: 0.22,    // 完全乱打一手的概率
      margin: 0.40,    // 跟注门槛系数（越小越松，什么牌都跟）
      iters: 70,       // 蒙特卡洛次数（越少越算不准）
      bluff: 1.60,     // 诈唬频率倍数
      raise: 0.55,     // 主动加注频率倍数
      tight: 0.60      // 紧度倍数
    },
    normal: {
      label: '普通',
      noise: 0.07,
      random: 0.06,
      margin: 1.00,
      iters: 150,
      bluff: 1.00,
      raise: 1.00,
      tight: 1.00
    },
    hard: {
      label: '困难',
      noise: 0.02,
      random: 0.01,
      margin: 1.45,    // 门槛更高，不轻易用边缘牌送钱
      iters: 240,
      bluff: 0.80,
      raise: 1.15,
      tight: 1.25
    }
  };

  /* 蒙特卡洛估算胜率（含平局分摊） */
  function equity(hole, board, nOpp, iters) {
    if (nOpp <= 0) return 1;
    var known = {}, i;
    for (i = 0; i < hole.length; i++) known[hole[i]] = true;
    for (i = 0; i < board.length; i++) known[board[i]] = true;
    var deck = [];
    for (i = 0; i < FULL_DECK.length; i++) if (!known[FULL_DECK[i]]) deck.push(FULL_DECK[i]);

    var needBoard = 5 - board.length;
    var need = nOpp * 2 + needBoard;
    var win = 0, tie = 0;

    for (var it = 0; it < iters; it++) {
      for (var a = 0; a < need; a++) {
        var j = a + Math.floor(Math.random() * (deck.length - a));
        var t = deck[a]; deck[a] = deck[j]; deck[j] = t;
      }
      var idx = 0;
      var fullBoard = board.slice();
      for (var b = 0; b < needBoard; b++) fullBoard.push(deck[idx++]);

      var heroScore = Poker.evaluate7(hole.concat(fullBoard)).score;
      var bestOpp = -1;
      for (var o = 0; o < nOpp; o++) {
        var oh = [deck[idx++], deck[idx++]];
        var sc = Poker.evaluate7(oh.concat(fullBoard)).score;
        if (sc > bestOpp) bestOpp = sc;
      }
      if (heroScore > bestOpp) win++;
      else if (heroScore === bestOpp) tie++;
    }
    return (win + tie * 0.5) / iters;
  }

  /* 预翻牌起手牌强度查表（0~1） */
  function preflopStrength(hole) {
    var r1 = Poker.rankOf(hole[0]), r2 = Poker.rankOf(hole[1]);
    var suited = Poker.suitOf(hole[0]) === Poker.suitOf(hole[1]);
    var hi = Math.max(r1, r2), lo = Math.min(r1, r2);
    var base = hi === lo ? (hi >= 10 ? 0.55 + (hi - 10) * 0.04 : 0.30 + hi * 0.02)
      : (hi - 2) * 0.028 + (lo - 2) * 0.012;
    if (hi === lo) base += 0.30;
    if (suited) base += 0.05;
    if (hi - lo === 1) base += 0.05;
    if (hi - lo > 4) base -= 0.03;
    if (hi === 14) base += 0.06;
    return Math.max(0.05, Math.min(0.97, base));
  }

  /* 低难度专用：瞎打一手 */
  function randomAction(ctx) {
    if (ctx.toCall <= 0) {
      if (Math.random() < 0.55) return { type: 'check' };
      return raiseTo(ctx, Math.max(ctx.pot * 0.5, ctx.bigBlind * 2));
    }
    return Math.random() < 0.5 ? { type: 'call' } : { type: 'fold' };
  }

  /*
   * ctx = {
   *   hole, board, street, pot, toCall, myChips, currentBet, myBetThisStreet,
   *   minRaiseTo, maxRaiseTo, nOpponents, bigBlind, personality, canCheck,
   *   difficulty: 'easy' | 'normal' | 'hard'
   * }
   */
  function decide(ctx) {
    var D = DIFFICULTY[ctx.difficulty] || DIFFICULTY.normal;
    var p = ctx.personality || {};
    var aggr = (p.aggr || 1.0) * D.raise;
    var tight = (p.tight || 1.0) * D.tight;
    var bluff = (p.bluff || 0.08) * D.bluff;

    // 难度越低，越容易做出莫名其妙的一手
    if (Math.random() < D.random) return randomAction(ctx);

    var eq;
    if (ctx.board.length === 0 && ctx.nOpponents >= 2) {
      eq = preflopStrength(ctx.hole) * Math.pow(0.72, ctx.nOpponents - 1);
    } else {
      eq = equity(ctx.hole, ctx.board, ctx.nOpponents, D.iters);
    }
    // 难度噪声：算得不准，判断就会错
    eq += (Math.random() - 0.5) * 2 * D.noise;
    eq = Math.min(0.98, Math.max(0.02, eq));

    var potOdds = ctx.toCall > 0 ? ctx.toCall / (ctx.pot + ctx.toCall) : 0;
    var pot = ctx.pot;
    var rnd = Math.random();
    var commitRatio = ctx.toCall / Math.max(1, ctx.myChips);

    if (ctx.toCall <= 0) {
      var betThreshold = 0.58 / aggr + (tight - 1) * 0.05;
      if (eq > 0.82 && rnd < 0.85) {
        return raiseTo(ctx, pot * (0.9 + Math.random() * 0.5));
      }
      if (eq > betThreshold) {
        if (rnd < 0.75 * aggr) return raiseTo(ctx, pot * (0.45 + Math.random() * 0.35));
        return { type: 'check' };
      }
      if (rnd < bluff * aggr * 0.6) {
        return raiseTo(ctx, pot * (0.4 + Math.random() * 0.3));
      }
      return { type: 'check' };
    }

    if (eq > 0.78 && commitRatio < 0.9) {
      if (Math.random() < 0.7 * aggr) return raiseTo(ctx, pot * (0.9 + Math.random() * 0.6));
    }
    if (eq > 0.62 && Math.random() < 0.35 * aggr) {
      return raiseTo(ctx, pot * (0.6 + Math.random() * 0.4));
    }

    var margin = 0.045 * tight / aggr * D.margin;
    var callable = eq > potOdds + margin;

    if (callable && ctx.toCall >= ctx.myChips * 0.75) {
      return { type: 'allin' };
    }
    if (callable) {
      if (eq - potOdds < margin * 2.2 && Math.random() < 0.22) return { type: 'fold' };
      return { type: 'call' };
    }
    if (rnd < bluff * 0.25 && ctx.toCall <= ctx.myChips * 0.06) return { type: 'call' };
    return { type: 'fold' };
  }

  /* 把「想加到多少」换算成合法加注 / 全下 */
  function raiseTo(ctx, target) {
    var to = Math.round(target);
    if (to < ctx.minRaiseTo) to = ctx.minRaiseTo;
    if (to >= ctx.maxRaiseTo) {
      if (to >= ctx.maxRaiseTo * 0.92) return { type: 'allin' };
      to = ctx.maxRaiseTo - 1;
      if (to < ctx.minRaiseTo) return { type: 'allin' };
    }
    return { type: 'raise', amount: to };
  }

  var API = {
    equity: equity,
    preflopStrength: preflopStrength,
    decide: decide,
    DIFFICULTY: DIFFICULTY
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  global.AI = API;
})(typeof window !== 'undefined' ? window : globalThis);
