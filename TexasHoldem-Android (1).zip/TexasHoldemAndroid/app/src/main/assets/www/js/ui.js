/* ==========================================================
 * ui.js —— 界面渲染与交互
 * 支持三种模式：solo（单人 6 人桌）/ host（联机房主）/ guest（联机加入方）
 * ========================================================== */
(function () {
  'use strict';

  var Poker = window.Poker;
  var STREET_CN = window.EngineAPI.STREET_CN;
  var $ = function (id) { return document.getElementById(id); };

  var LS_KEY = 'th_local_v1';
  var DIFF_KEY = 'th_diff_v1';
  var DIFF_CN = { easy: '简单', normal: '普通', hard: '困难' };
  var DIFF_DESC = {
    easy: 'AI 判断经常失准，会乱跟注、乱弃牌，适合熟悉规则',
    normal: 'AI 会算胜率、照赔率跟注，偶尔犯错',
    hard: 'AI 算得更准、更少犯蠢，边缘牌不轻易送钱'
  };

  /* ---------------- 运行时状态 ---------------- */
  var engine = null;              // solo / host 有引擎；guest 没有
  var mode = 'solo';              // 'solo' | 'host' | 'guest'
  var mySeat = 0;                 // 自己坐哪
  var remoteSeat = 1;
  var difficulty = 'normal';
  var stats = { hands: 0, best: 0 };
  var speedLevel = 1;
  var SPEEDS = [420, 780, 1250];
  var aiTimer = null;
  var turnTimer = null;
  var heroTurnActive = false;
  var lastState = null;
  var lastBannerKey = null;
  var netRole = 'host';
  var netBusy = false;
  var roomOpen = false;
  var netDropped = false;
  var chatUnread = 0;
  var chatFeedTimer = null;
  var myName = '';              // 自己在房间里的昵称
  var seatNames = {};           // 房主侧：seat -> 昵称
  var seatChat = {};        // seat -> { text, until } 头像旁的聊天气泡
  var chatHistory = [];     // 最近的消息，关面板后补显示用
  var myRoomId = '';

  /* 座位排布：横向等距，纵向贴着椭圆弧线，保证视觉均匀、不重叠 */
  function seatPositions(n) {
    if (n <= 0) return [];
    if (n === 1) return [{ l: 50, t: 15 }];
    var out = [];
    var left = 13, right = 87;                 // 横向占位范围
    for (var i = 0; i < n; i++) {
      var l = left + (right - left) * (i / (n - 1));
      var dx = (l - 50) / 37;                  // -1 ~ 1
      var dy = Math.sqrt(Math.max(0, 1 - dx * dx));
      var t = 27 - 15 * dy;                    // 中间高(12%)、两侧低(27%)
      out.push({ l: Math.round(l), t: Math.round(t) });
    }
    return out;
  }

  /* ---------------- 通用工具 ---------------- */
  function setVisible(el, on) {
    if (typeof el === 'string') el = $(el);
    if (!el) return;
    if (on) { el.classList.remove('hidden'); el.style.display = ''; }
    else { el.classList.add('hidden'); el.style.display = 'none'; }
  }

  function syncViewport() {
    var h = (window.visualViewport && window.visualViewport.height)
      ? window.visualViewport.height : window.innerHeight;
    document.documentElement.style.setProperty('--app-h', (h - 1) + 'px');
  }

  function cardHTML(card, cls) {
    var r = Poker.rankOf(card), su = Poker.suitOf(card);
    var red = (su === 'h' || su === 'd') ? ' red' : '';
    return '<div class="card' + red + (cls ? ' ' + cls : '') + '">' +
      '<span class="r">' + Poker.rankLabel(r) + '</span>' +
      '<span class="s">' + Poker.SUIT_SYMBOL[su] + '</span></div>';
  }
  function backHTML(cls) { return '<div class="card back' + (cls ? ' ' + cls : '') + '"></div>'; }
  function fmt(n) { return n >= 10000 ? (n / 1000).toFixed(1) + 'k' : String(n); }
  function preflopLabel(hole) {
    var r1 = Poker.rankOf(hole[0]), r2 = Poker.rankOf(hole[1]);
    var suited = Poker.suitOf(hole[0]) === Poker.suitOf(hole[1]);
    var hi = Math.max(r1, r2), lo = Math.min(r1, r2);
    if (hi === lo) return Poker.rankLabel(hi) + Poker.rankLabel(lo);
    return Poker.rankLabel(hi) + Poker.rankLabel(lo) + (suited ? 's' : 'o');
  }

  function loadStats() {
    try {
      var raw = localStorage.getItem(LS_KEY);
      if (raw) { var d = JSON.parse(raw); if (d && typeof d.hands === 'number') stats = d; }
    } catch (e) { }
  }
  function saveStats() { try { localStorage.setItem(LS_KEY, JSON.stringify(stats)); } catch (e) { } }

  function loadDifficulty() {
    try { var v = localStorage.getItem(DIFF_KEY); if (v && DIFF_DESC[v]) difficulty = v; } catch (e) { }
  }
  function applyDifficulty(level, persist) {
    if (!DIFF_DESC[level]) level = 'normal';
    difficulty = level;
    if (engine) engine.setDifficulty(level);
    var btns = document.querySelectorAll('#diffSeg .seg-btn');
    for (var i = 0; i < btns.length; i++) {
      if (btns[i].getAttribute('data-diff') === level) btns[i].classList.add('active');
      else btns[i].classList.remove('active');
    }
    var hint = $('diffHint'); if (hint) hint.textContent = DIFF_DESC[level] || '';
    var tag = $('diffLabel'); if (tag) tag.textContent = DIFF_CN[level] || '普通';
    if (persist) { try { localStorage.setItem(DIFF_KEY, level); } catch (e) { } }
  }

  function setDrawer(open) {
    var d = $('drawer');
    if (!d) return;
    if (open) { d.classList.remove('hidden'); d.style.display = 'flex'; }
    else { d.classList.add('hidden'); d.style.display = 'none'; }
  }

  /* ---------------- 构造状态快照 ---------------- */
  function buildState() {
    if (!engine) return lastState;
    var s = engine.snapshot();
    s.legal = (engine.inHand && engine.actor >= 0) ? engine.legal(engine.actor) : null;
    s.youSeat = mySeat;
    return s;
  }

  /* 发给客机的状态：必须遮掉客机不该看到的底牌 */
  /* 给某个座位生成「只能看到自己底牌」的状态 */
  function buildStateFor(seat) {
    var st = engine.snapshot();
    for (var i = 0; i < st.players.length; i++) {
      if (i === seat) continue;
      if (!st.players[i].showdown) st.players[i].hole = [];
    }
    st.legal = (engine.inHand && engine.actor >= 0) ? engine.legal(engine.actor) : null;
    st.youSeat = seat;
    return st;
  }

  function sendState() { broadcast(); }

  /* 房主把状态发给每个客机 */
  function broadcast() {
    if (mode !== 'host' || !engine || !window.Net) return;
    var seats = Net.seats();
    for (var i = 0; i < seats.length; i++) {
      var st = seats[i];
      if (!engine.players[st]) continue;
      Net.sendTo(st, { t: 'state', s: buildStateFor(st) });
    }
  }

  /* ---------------- 渲染 ---------------- */
  function render(s) {
    s = s || buildState();
    if (!s) return;
    lastState = s;
    $('potVal').textContent = fmt(s.pot);
    $('handNo').textContent = '第 ' + s.handNo + ' 手';
    $('streetLabel').textContent = STREET_CN[s.street] || '——';
    renderBoard(s);
    renderSeats(s);
    renderHero(s);
  }

  function renderBoard(s) {
    var html = '';
    for (var i = 0; i < 5; i++) {
      html += s.board[i] ? cardHTML(s.board[i]) : '<div class="card hidden"></div>';
    }
    var b = $('board');
    if (b.getAttribute('data-b') !== html) { b.innerHTML = html; b.setAttribute('data-b', html); }
    $('potChips').textContent = s.pot > 0 ? '底池 ' + fmt(s.pot) : '';
  }

  function renderSeats(s) {
    var others = [];
    for (var i = 0; i < s.players.length; i++) if (i !== mySeat) others.push(s.players[i]);
    var posList = seatPositions(others.length);

    var html = '';
    for (var k = 0; k < others.length; k++) {
      var p = others[k];
      var pos = posList[k] || { l: 50, t: 20 };
      var acting = (s.actor === p.seat) ? ' acting' : '';
      var foldedCls = p.folded ? ' folded' : '';
      var cards = '';
      if (p.inHand && !p.folded) {
        if (p.showdown && p.hole && p.hole.length) {
          cards = p.hole.map(function (c) { return cardHTML(c); }).join('');
        } else {
          cards = backHTML() + backHTML();      // 永远显示牌背，不泄露
        }
      }
      var bubble = '';
      var isChat = false;
      var cb = seatChat[p.seat];
      if (cb && Date.now() < cb.until) {
        bubble = cb.text;
        isChat = true;
      } else if (p.showdown && s.result && s.result.type === 'showdown') {
        bubble = p.showdown;
      } else {
        bubble = p.lastAction || '';
        // 「小盲 10」「跟注 20」里的数字和下注额重复，去掉更清爽
        bubble = bubble.replace(/^(小盲|大盲|跟注)\s*\d+$/, '$1');
      }

      html += '<div class="seat' + acting + foldedCls + '" style="left:' + pos.l + '%;top:' + pos.t + '%">' +
        (cards ? '<div class="mini-cards">' + cards + '</div>' : '') +
        '<span class="avatar">' + p.avatar + '</span>' +
        '<div class="nm">' + p.name + '</div>' +
        '<div class="chips">' + fmt(p.chips) + '</div>' +
        '<div class="bet">' + (p.betStreet > 0 ? fmt(p.betStreet) : '') + '</div>' +
        '<div class="bubble' + (isChat ? ' chat' : '') + '">' + (isChat ? '💬 ' + bubble : bubble) + '</div>' +
        '</div>';
    }
    var el = $('seats');
    if (el.getAttribute('data-h') !== html) { el.innerHTML = html; el.setAttribute('data-h', html); }
  }

  function renderHero(s) {
    var h = s.players[mySeat];
    if (!h) return;
    var cardsHTML = '';
    if (h.hole.length) {
      var cls = h.folded ? 'dim' : '';
      cardsHTML = h.hole.map(function (c) { return cardHTML(c, cls); }).join('');
    }
    var hc = $('heroCards');
    var key = cardsHTML + (h.folded ? 'F' : '');
    if (hc.getAttribute('data-k') !== key) { hc.innerHTML = cardsHTML; hc.setAttribute('data-k', key); }

    $('heroChips').textContent = fmt(h.chips);
    var hi = $('heroInfo');
    if (h.folded) hi.classList.add('folded'); else hi.classList.remove('folded');

    var hn = '';
    if (h.hole.length === 2 && s.board.length >= 3 && !h.folded) {
      hn = Poker.evaluate7(h.hole.concat(s.board)).name;
    } else if (h.hole.length === 2 && !h.folded) {
      hn = preflopLabel(h.hole);
    }
    $('heroHand').textContent = hn;
  }

  /* ---------------- 操作区 ---------------- */
  function showHeroActions(s) {
    var lg = s.legal;
    if (!lg) return;
    var me = s.players[mySeat];
    if (!me) return;

    setVisible('btnRow', true);
    setVisible('nextRow', false);

    var callBtn = $('btnCall');
    if (lg.canCheck) callBtn.textContent = '过牌';
    else if (lg.toCall >= me.chips) callBtn.textContent = '全下 ' + lg.toCall;
    else callBtn.textContent = '跟注 ' + lg.toCall;

    var raiseBtn = $('btnRaise');
    var panel = $('raisePanel');
    if (!lg.canRaise) {
      raiseBtn.disabled = true;
      panel.classList.add('disabled');
    } else {
      raiseBtn.disabled = false;
      panel.classList.remove('disabled');
      raiseBtn.textContent = s.currentBet > 0 ? '加注' : '下注';
      var slider = $('raiseSlider');
      slider.min = lg.minRaiseTo;
      slider.max = lg.maxRaiseTo;
      slider.step = 5;
      var pre = Math.min(lg.maxRaiseTo, Math.max(lg.minRaiseTo, Math.round((s.currentBet + lg.pot * 0.6) / 5) * 5));
      slider.value = pre;
      $('raiseVal').textContent = pre;
    }
    heroTurnActive = true;
  }

  function hideActions(showNext) {
    heroTurnActive = false;
    setVisible('btnRow', false);
    setVisible('nextRow', !!showNext);
  }

  function doAction(a) {
    if (!heroTurnActive) return;
    heroTurnActive = false;
    setVisible('btnRow', false);
    if (mode === 'guest') {
      if (!window.Net || !Net.send({ t: 'act', a: a })) {
        setNetStatus('发送失败：连接已断开');
      }
      return;
    }
    if (!engine) return;
    engine.act(engine.actor, a);
    drive();
  }

  /* ---------------- 驱动 ---------------- */
  function drive() {
    clearTimeout(aiTimer);
    if (mode === 'host') return driveNet();
    if (mode !== 'solo' || !engine || !engine.inHand) return;

    if (engine.actorIsHero()) {
      var p = engine.players[engine.actor];
      if (p.allin || p.folded) { hideActions(false); return; }
      showHeroActions(buildState());
      return;
    }
    hideActions(false);
    aiTimer = setTimeout(function () {
      if (!engine || !engine.inHand) return;
      if (engine.actorIsHero()) { drive(); return; }
      engine.aiAct();
      drive();
    }, SPEEDS[speedLevel] * (0.75 + Math.random() * 0.5));
  }

  function driveNet() {
    clearTimeout(aiTimer);
    clearTimeout(turnTimer);
    if (mode !== 'host' || !engine) return;
    if (!engine.inHand) return;
    var s = buildState();
    render(s);
    sendState();

    if (engine.actor === mySeat) {
      var p = engine.players[mySeat];
      if (p.allin || p.folded) { hideActions(false); return; }
      showHeroActions(s);
    } else {
      hideActions(false);
      // 等客机出牌；对方掉线或卡住时，超时自动替他弃牌，避免整局卡死
      var waitSeat = engine.actor;
      var waitName = (engine.players[waitSeat] || {}).name || '玩家';

      // 对方连接已经断了：不用等，立刻替他弃牌
      if (window.Net && Net.seatCount() > 0 && !Net.isSeatOpen(waitSeat)) {
        var deadP = engine.players[waitSeat];
        if (deadP && !deadP.folded && !deadP.allin) {
          engine.act(waitSeat, { type: 'fold' });
          var db = $('banner');
          db.innerHTML = '<div class="big">' + waitName + ' 已离线</div><div class="sub">自动弃牌</div>';
          setVisible(db, true);
          setTimeout(hideBanner, 2000);
          driveNet();
          return;
        }
      }

      turnTimer = setTimeout(function () {
        if (!engine || !engine.inHand || engine.actor !== waitSeat) return;
        var wp = engine.players[waitSeat];
        if (!wp || wp.folded || wp.allin) return;
        engine.act(waitSeat, { type: 'fold' });
        var b = $('banner');
        b.innerHTML = '<div class="big">' + waitName + ' 超时</div><div class="sub">已自动弃牌</div>';
        setVisible(b, true);
        setTimeout(hideBanner, 2000);
        driveNet();
      }, 45000);
    }
  }

  /* 对局中有人掉线：该座位本手自动弃牌，不卡住牌局 */
  function handleSeatLeave(seat) {
    var p = engine && engine.players[seat];
    if (!p) return;
    if (engine.inHand && p.inHand && !p.folded) {
      if (engine.actor === seat && !p.allin) {
        engine.act(seat, { type: 'fold' });
        driveNet();
      } else {
        p.folded = true;
        if (engine.inHand) engine.advance();
        render(buildState());
        broadcast();
      }
    }
    var b = $('banner');
    if (window.Net && Net.seatCount() === 0) {
      // 人都走光了，房主也只剩自己，直接给出口
      netDropped = true;
      b.innerHTML = '<div class="big">玩家都离开了</div><div class="sub">没对手了，点下面按钮回大厅</div>';
      setVisible(b, true);
      hideActions(false);
      setVisible('nextRow', true);
      $('btnNext').disabled = false;
      $('btnNext').textContent = '返回大厅';
      return;
    }
    b.innerHTML = '<div class="big">玩家' + (seat + 1) + ' 离开了</div><div class="sub">该座位本手自动弃牌</div>';
    setVisible(b, true);
    setTimeout(hideBanner, 2500);
  }

  /* ---------------- 结算横幅 ---------------- */
  function hideBanner() {
    var b = $('banner');
    if (!b) return;
    b.classList.remove('show');
    setVisible(b, false);
  }

  function showBanner(s) {
    var r = s && s.result;
    if (!r || !r.type) return;
    var myWin = 0, winNames = [], seen = {};
    (r.pots || []).forEach(function (pot) {
      if (pot.winners.indexOf(mySeat) >= 0) myWin += pot.amount;
      pot.winners.forEach(function (si) {
        if (seen[si]) return;
        seen[si] = true;
        var p = s.players[si] || {};
        var hd = r.hands && r.hands[si] ? r.hands[si].name : '';
        winNames.push((si === mySeat ? '你' : (p.name || '对手')) + (hd ? '（' + hd + '）' : ''));
      });
    });

    var lines = [];
    if (r.type === 'fold') {
      var wName = (r.winners[0] === mySeat) ? '你' : ((s.players[r.winners[0]] || {}).name || '对手');
      lines.push('<div class="big">' + (myWin > 0 ? '你赢得 ' + fmt(myWin) : wName + ' 赢得底池 ' + fmt(r.pots[0].amount)) + '</div>');
      lines.push('<div class="sub">无人跟注</div>');
    } else {
      lines.push('<div class="big">' + (myWin > 0 ? '你赢得 ' + fmt(myWin) : '本手输了') + '</div>');
      lines.push('<div class="sub">赢家：' + winNames.join('、') + '</div>');
      if (r.pots.length > 1) {
        lines.push('<div class="sub">' + r.pots.map(function (p, i) {
          return (i === 0 ? '主池' : '边池' + i) + ' ' + fmt(p.amount);
        }).join(' · ') + '</div>');
      }
    }
    var banner = $('banner');
    banner.innerHTML = lines.join('');
    setVisible(banner, true);
    setTimeout(function () { banner.classList.add('show'); }, 30);
  }

  function onHandEnd(result) {
    clearTimeout(aiTimer);
    hideActions(mode !== 'guest');
    stats.hands++;
    var myWin = 0;
    (result.pots || []).forEach(function (pot) {
      if (pot.winners.indexOf(mySeat) >= 0) myWin += pot.amount;
    });
    if (myWin > stats.best) stats.best = myWin;
    saveStats();

    var s = buildState();
    render(s);
    showBanner(s);
    sendState();

    if (mode !== 'guest' && engine) {
      $('btnNext').textContent = engine.players[mySeat].chips <= 0 ? '重新开始（重置筹码）' : '下一手';
    }
  }

  /* ---------------- 房间聊天 ---------------- */
  function myChatName() {
    if (myName) return myName;
    if (mode === 'host') return '房主';
    if (mode === 'guest') return '玩家' + (mySeat + 1);
    return '我';
  }

  function addChat(name, text, isMe) {
    var feed = $('chatFeed');
    if (!feed) return;
    var line = document.createElement('div');
    line.className = 'chat-line';
    var who = document.createElement('span');
    who.className = 'who' + (isMe ? ' me' : '');
    who.textContent = name + '：';
    var body = document.createElement('span');
    body.textContent = text;              // textContent，避免注入
    line.appendChild(who);
    line.appendChild(body);
    feed.appendChild(line);

    while (feed.children.length > 5) feed.removeChild(feed.firstChild);
    feed.scrollTop = feed.scrollHeight;
    setVisible(feed, true);

    // 显示 8 秒后自动收起；期间来了新消息就重新计时
    clearTimeout(chatFeedTimer);
    chatFeedTimer = setTimeout(function () {
      setVisible(feed, false);
    }, 8000);
  }

  function pushChatHistory(seat, text) {
    chatHistory.push({ seat: seat, text: text });
    if (chatHistory.length > 20) chatHistory.shift();
  }

  function setSeatChat(seat, text) {
    if (typeof seat !== 'number' || seat === mySeat) return;
    var short = text.length > 14 ? text.slice(0, 14) + '…' : text;
    var rec = seatChat[seat] || {};
    clearTimeout(rec.timer);
    seatChat[seat] = { text: short, until: Date.now() + 3200, timer: null };
    seatChat[seat].timer = setTimeout(function () {
      delete seatChat[seat];
      render();
    }, 3200);
    render();
  }

  function sendChat() {
    var input = $('chatInput');
    if (!input) return;
    var text = (input.value || '').trim();
    if (!text) return;
    if (text.length > 100) text = text.slice(0, 100);
    input.value = '';

    var me = myChatName();
    addChat(me, text, true);

    if (window.Net) {
      if (mode === 'host') {
        var seats = Net.seats();
        for (var i = 0; i < seats.length; i++) {
          Net.sendTo(seats[i], { t: 'chat', name: '房主', text: text });
        }
      } else if (mode === 'guest') {
        Net.send({ t: 'chat', text: text });
      }
    }
    closeChat();          // 发完自动收起，牌桌立刻恢复
  }

  function openChat() {
    setVisible('chatBar', true);
    var inp = $('chatInput');
    if (!inp) return;
    inp.value = '';
    setTimeout(function () { try { inp.focus(); } catch (e) { } }, 60);
  }

  function closeChat() {
    setVisible('chatBar', false);
    var inp = $('chatInput');
    if (inp) { inp.value = ''; inp.blur(); }
  }

  function resetChat() {
    clearTimeout(chatFeedTimer);
    for (var k in seatChat) { clearTimeout(seatChat[k].timer); }
    seatChat = {};
    chatHistory = [];
    var feed = $('chatFeed');
    if (feed) { feed.innerHTML = ''; }
    setVisible(feed, false);
    closeChat();
  }

  /* ---------------- 退出联机房间 ---------------- */
  function leaveRoom() {
    clearTimeout(aiTimer);
    clearTimeout(turnTimer);
    if (window.Net) Net.closeAll();
    var lip = $('lanIpShow');
    if (lip) lip.textContent = '---';
    var lpl = $('lanPlayers');
    if (lpl) lpl.innerHTML = '';
    mode = 'lobby';
    netDropped = false;
    roomOpen = false;
    myRoomId = '';
    seatNames = {};
    engine = null;
    lastState = null;
    lastBannerKey = null;
    hideBanner();
    hideActions(false);
    setDrawer(false);
    setVisible('chatBtn', false);
    resetChat();
    var rc = $('roomCodeShow');
    if (rc) rc.textContent = '----';
    var pl = $('playerList');
    if (pl) pl.innerHTML = '';
    var bc = $('btnCreateRoom');
    if (bc) bc.textContent = '创建房间';
    var sg = $('btnStartGame');
    if (sg) { sg.disabled = true; sg.textContent = '开始游戏（至少 2 人）'; }
    refreshPlayerList();
    setNetStatus('同屋的话连同一个 WiFi 更稳', '');
    showLobby();
  }

  /* ---------------- 引擎装配 ---------------- */
  function makeSoloEngine() {
    engine = new window.Engine({ startChips: 2000, blinds: [10, 20], difficulty: difficulty });
    engine.on('state', function () { if (mode === 'solo') render(); });
    engine.on('handEnd', onHandEnd);
  }

  function makeNetEngine(n) {
    n = Math.max(2, Math.min(4, n || 2));
    var av = ['🎩', '🐼', '🦊'];
    var personas = [{ name: myName || '房主', avatar: '🙂', tag: '房主', aggr: 1, tight: 1, bluff: 0.08 }];
    for (var i = 1; i < n; i++) {
      personas.push({
        name: seatNames[i] || ('玩家' + (i + 1)),
        avatar: av[i - 1] || '🎯',
        tag: '客机', aggr: 1, tight: 1, bluff: 0.08
      });
    }
    engine = new window.Engine({ startChips: 2000, blinds: [10, 20], personas: personas });
    engine.on('state', function () { if (mode === 'host') render(); });
    engine.on('handEnd', onHandEnd);
  }

  /* ---------------- 联机面板 ---------------- */
  function setNetStatus(text, kind) {
    var el = $('netStatus');
    if (!el) return;
    el.textContent = text;
    el.className = 'net-status' + (kind ? ' ' + kind : '');
  }

  function copyFrom(id) {
    var el = $(id);
    if (!el || !el.value) return;
    el.removeAttribute('readonly');
    el.select();
    el.setSelectionRange(0, el.value.length);
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    el.setAttribute('readonly', 'readonly');
    if (!ok && navigator.clipboard) {
      navigator.clipboard.writeText(el.value).then(function () {
        setNetStatus('已复制到剪贴板', 'ok');
      }).catch(function () {
        setNetStatus('复制失败，请长按输入框手动全选复制', 'err');
      });
      return;
    }
    setNetStatus(ok ? '已复制到剪贴板' : '复制失败，请长按输入框手动全选复制', ok ? 'ok' : 'err');
  }

  function showLobby() {
    setVisible('lobby', true);
    setVisible('netPanel', false);
  }

  function showNetPanel() {
    netDropped = false;
    setVisible('lobby', false);
    setVisible('netPanel', true);
    setNetStatus('两台手机需要连同一个 WiFi', '');
  }

  function enterSolo() {
    mode = 'solo'; mySeat = 0; remoteSeat = 1;
    netDropped = false;
    setVisible('chatBtn', false);
    resetChat();
    setVisible('lobby', false);
    setVisible('netPanel', false);
    makeSoloEngine();
    applyDifficulty(difficulty, false);
    engine.startHand();
    render();
    drive();
  }

  function startHostGame(n) {
    mode = 'host'; mySeat = 0; remoteSeat = 1;
    roomOpen = false;
    if (window.Net) Net.setAccepting(false);   // 开局后不再接收新玩家
    setVisible('netPanel', false);
    setVisible('lobby', false);
    resetChat();
    setVisible('chatBtn', true);
    makeNetEngine(n);
    engine.startHand();
    render();
    driveNet();
  }

  function enterGuestView() {
    mode = 'guest';
    netDropped = false;
    engine = null;                 // 客机没有本地引擎，别让单人模式残留状态干扰渲染
    clearTimeout(aiTimer);
    clearTimeout(turnTimer);
    resetChat();
    setVisible('chatBtn', true);
    setVisible('netPanel', false);
    setVisible('lobby', false);
    if (lastState) render(lastState);
    hideActions(false);
  }

  function refreshPlayerList() {
    var seats = window.Net ? Net.seats() : [];
    var html = '<div class="pl-item me">' + (myName || '房主') + '（你）</div>';
    for (var i = 0; i < seats.length; i++) {
      html += '<div class="pl-item">' + (seatNames[seats[i]] || ('玩家' + (seats[i] + 1))) + ' 已加入</div>';
    }
    var el = $('playerList');
    if (el) el.innerHTML = html;
    var n = seats.length + 1;
    var btn = $('btnStartGame');
    if (btn) {
      btn.disabled = n < 2;
      btn.textContent = n < 2 ? '开始游戏（至少 2 人）' : '开始游戏（' + n + ' 人）';
    }
  }

  function refreshLanPlayers() {
    var el = $('lanPlayers');
    if (!el) return;
    var seats = (window.Net && Net.seats) ? Net.seats() : [];
    var html = '<div class="pl-item me">' + (myName || '房主') + '（你）</div>';
    for (var i = 0; i < seats.length; i++) {
      html += '<div class="pl-item">' + (seatNames[seats[i]] || ('玩家' + (seats[i] + 1))) + ' 已加入</div>';
    }
    el.innerHTML = html;
    var btn = $('btnLanStartGame');
    if (btn) {
      var n = seats.length + 1;
      btn.disabled = n < 2;
      btn.textContent = n < 2 ? '开始游戏（至少 2 人）' : '开始游戏（' + n + ' 人）';
    }
  }

  function bindNet() {
    if (!window.Net) return;
    refreshPlayerList();

    /* ================= 房主：创建房间 ================= */
    $('btnCreateRoom').addEventListener('click', function () {
      if (netBusy) return;
      if (roomOpen && window.Net && Net.seatCount() > 0) {
        return setNetStatus('房间里已经有人了，换号会把对方踢掉；先让对方退出再换', 'err');
      }
      netBusy = true;
      myName = ($('hostName').value || '').trim().slice(0, 8);
      $('roomCodeShow').textContent = '····';
      setNetStatus('正在创建房间…（最多重试 3 次）');
      Net.hostRoom().then(function (actualId) {
        myRoomId = actualId;
        roomOpen = true;
        $('roomCodeShow').textContent = actualId;
        $('btnCreateRoom').textContent = '换个房间号';
        refreshPlayerList();
        setNetStatus('房间已建好，把 ' + actualId + ' 告诉朋友，等他们进来', 'ok');
      }).catch(function (e) {
        $('roomCodeShow').textContent = '----';
        myRoomId = '';
        roomOpen = false;
        $('btnCreateRoom').textContent = '创建房间';
        setNetStatus((e.message || '创建失败') + '。可以再点一次，或用下面的连接码模式', 'err');
      }).then(function () { netBusy = false; });
    });

    Net.on('peer-join', function (seat) {
      refreshLanPlayers();
      if (!roomOpen) return;
      refreshPlayerList();
      setNetStatus('玩家' + (seat + 1) + ' 已进入房间', 'ok');
    });
    Net.on('peer-left', function (seat) {
      if (roomOpen) {
        refreshPlayerList();
        setNetStatus('玩家' + (seat + 1) + ' 离开了房间', '');
        return;
      }
      if (mode === 'host' && engine) handleSeatLeave(seat);
    });
    Net.on('server-lost', function () {
      setNetStatus('和联机服务器断开了，建议改用连接码模式', 'err');
    });

    $('btnStartGame').addEventListener('click', function () {
      var n = (window.Net ? Net.seatCount() : 0) + 1;
      if (n < 2) return;
      startHostGame(n);
    });

    /* ================= 加入方：输房间号 ================= */
    $('btnJoinRoom').addEventListener('click', function () {
      var id = ($('roomInput').value || '').replace(/\D/g, '');
      if (id.length !== 4) return setNetStatus('请输入 4 位数字房间号', 'err');
      if (netBusy) return;
      netBusy = true;
      setNetStatus('正在加入房间 ' + id + '…');
      myName = ($('guestName').value || '').trim().slice(0, 8);
      Net.joinRoom(id).then(function () {
        if (myName) Net.send({ t: 'hello', name: myName });
        setNetStatus('已进入房间，等房主点开始', 'ok');
      }).catch(function (e) {
        setNetStatus(e.message || '加入失败', 'err');
      }).then(function () { netBusy = false; });
    });

    /* ================= 消息 ================= */
    Net.on('message', function (m, fromSeat) {
      if (!m) return;

      if (m.t === 'act') {
        if (mode === 'host' && engine && typeof fromSeat === 'number') {
          engine.act(fromSeat, m.a);
          driveNet();
        }
        return;
      }

      if (m.t === 'hello') {
        if (mode === 'host' || roomOpen) {
          var nm2 = String(m.name || '').trim().slice(0, 8);
          seatNames[fromSeat] = nm2 || ('玩家' + (fromSeat + 1));
          refreshPlayerList();
        }
        return;
      }

      if (m.t === 'chat') {
        var txt = String(m.text || '').slice(0, 100);
        if (!txt) return;
        if (mode === 'host') {
          var nm = seatNames[fromSeat] || ('玩家' + (fromSeat + 1));
          addChat(nm, txt, false);
          setSeatChat(fromSeat, txt);
          pushChatHistory(fromSeat, txt);
          // 转发给其他客机，形成群聊
          var seats = window.Net ? Net.seats() : [];
          for (var ci = 0; ci < seats.length; ci++) {
            if (seats[ci] === fromSeat) continue;
            Net.sendTo(seats[ci], { t: 'chat', name: nm, seat: fromSeat, text: txt });
          }
        } else if (mode === 'guest') {
          addChat(m.name || '房主', txt, false);
          var cs = (typeof m.seat === 'number') ? m.seat : 0;
          setSeatChat(cs, txt);
          pushChatHistory(cs, txt);
        }
        return;
      }

      if (m.t === 'reject') {
        setNetStatus('这个房间已经开局了，等这局结束再加入吧', 'err');
        mode = 'lobby';
        setVisible('netPanel', true);
        setVisible('lobby', false);
        return;
      }

      if (m.t === 'state') {
        if (mode !== 'guest') enterGuestView();
        lastState = m.s;
        if (typeof m.s.youSeat === 'number') mySeat = m.s.youSeat;

        var hasResult = !!(m.s.result && m.s.result.type);
        render(m.s);

        if (hasResult) {
          hideActions(false);
          setVisible('nextRow', true);
          $('btnNext').disabled = true;
          $('btnNext').textContent = '等待房主开始下一手…';
          var key = (m.s.handNo || 0) + ':' + m.s.result.type;
          if (key !== lastBannerKey) { lastBannerKey = key; showBanner(m.s); }
        } else {
          hideBanner();
          lastBannerKey = null;
          $('btnNext').disabled = false;
          if (m.s.legal && m.s.actor === mySeat) {
            var me = m.s.players[mySeat];
            if (me && !me.allin && !me.folded) showHeroActions(m.s);
            else hideActions(false);
          } else {
            hideActions(false);
          }
        }
      }
    });

    /* 连接码模式连上时（只有这条路会触发 open） */
    Net.on('open', function () {
      if (netRole === 'host') startHostGame(2);
      else setNetStatus('已连上房主，等对方开始', 'ok');
    });

    Net.on('close', function () {
      if (mode === 'guest') {
        netDropped = true;
        $('banner').innerHTML = '<div class="big">房主离开了</div><div class="sub">这一局没法继续了</div>';
        setVisible('banner', true);
        hideActions(false);
        setVisible('nextRow', true);
        $('btnNext').disabled = false;
        $('btnNext').textContent = '返回大厅';
        setVisible('btnLeaveRoom', true);
      } else if (mode === 'host') {
        $('banner').innerHTML = '<div class="big">联机服务器断开了</div><div class="sub">当前这手打完请重开房间</div>';
        setVisible('banner', true);
      }
    });

    /* ================= 局域网直连（原生 TCP，无需服务器） ================= */
    Net.on('lan-error', function (msg) {
      setNetStatus(msg || '局域网出错', 'err');
    });

    $('btnLanStart').addEventListener('click', function () {
      if (!window.Net || !Net.lanSupported()) {
        return setNetStatus('局域网直连只能在 APP 里用，网页版请用房间号或连接码', 'err');
      }
      myName = ($('hostName').value || '').trim().slice(0, 8);
      setNetStatus('正在开启房间…');
      Net.hostLan(9528).then(function (ip) {
        var last = ip.split('.').pop();
        $('lanIpShow').textContent = ip;
        refreshLanPlayers();
        setNetStatus('房间已开好，让对方输入最后一段：' + last, 'ok');
      }).catch(function (e) {
        setNetStatus(e.message || '开启失败', 'err');
        $('lanIpShow').textContent = '---';
      });
    });

    $('btnLanJoin').addEventListener('click', function () {
      if (!window.Net || !Net.lanSupported()) {
        return setNetStatus('局域网直连只能在 APP 里用，网页版请用房间号或连接码', 'err');
      }
      var v = ($('lanIpInput').value || '').trim();
      if (!v) return setNetStatus('先输入房主地址的最后一段数字', 'err');

      var target = v;
      if (v.indexOf('.') < 0) {
        // 只输了最后一段，用自己手机的网段补全
        var myIp = Net.lanIp() || '';
        var dot = myIp.lastIndexOf('.');
        if (dot < 0) return setNetStatus('拿不到本机地址，请直接输入完整 IP', 'err');
        target = myIp.substring(0, dot + 1) + v;
      }

      myName = ($('guestName').value || '').trim().slice(0, 8);
      setNetStatus('正在连接 ' + target + ' …');
      Net.joinLan(target, 9528).then(function () {
        if (myName) Net.send({ t: 'hello', name: myName });
        setNetStatus('已连上房主，等他开始', 'ok');
      }).catch(function (e) {
        setNetStatus(e.message || '连接失败', 'err');
      });
    });

    $('btnLanStartGame').addEventListener('click', function () {
      var n = (window.Net ? Net.seatCount() : 0) + 1;
      if (n < 2) return;
      startHostGame(n);
    });

    $('btnLanMode').addEventListener('click', function () {
      var box = $('lanBox');
      var open = box.classList.contains('hidden');
      setVisible(box, open);
      $('btnLanMode').textContent = open ? '收起局域网直连 ▴' : '局域网直连（APP 内，不用服务器） ▾';
      if (open) {
        setVisible('lanHostBox', netRole === 'host');
        setVisible('lanJoinBox', netRole === 'guest');
      }
    });

    /* ================= 连接码模式（兜底）：一个框 + 一个按钮 ================= */
    function setCodeHint(text, kind) {
      var el = $('codeHint');
      if (!el) return;
      el.textContent = text;
      el.className = 'net-status' + (kind ? ' ' + kind : '');
    }

    function copyText(text) {
      if (!text) return false;
      var ok = false;
      try {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.top = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        ok = document.execCommand('copy');
        document.body.removeChild(ta);
      } catch (e) { ok = false; }
      if (!ok && navigator.clipboard) {
        navigator.clipboard.writeText(text).catch(function () { });
        ok = true;
      }
      return ok;
    }

    function updateCodeButton() {
      var box = $('codeBox'), btn = $('btnCodeAction');
      if (!box || !btn) return;
      var val = (box.value || '').trim();
      if (!val) { btn.textContent = '生成我的连接码'; return; }
      var kind = window.Net ? Net.classify(val) : 'unknown';
      if (kind === 'offer') btn.textContent = '生成应答码';
      else if (kind === 'answer') btn.textContent = '完成连接';
      else btn.textContent = '码不完整，重新粘贴';
    }

    function codeAction() {
      if (netBusy) return;
      var box = $('codeBox');
      var val = (box.value || '').trim();

      /* 空框 → 生成自己这一份 */
      if (!val) {
        netBusy = true;
        setCodeHint('正在生成…（约 2 秒）');
        Net.createCode().then(function (code) {
          box.value = code;
          var ok = copyText(code);
          updateCodeButton();
          setCodeHint(ok ? '已复制，发给对方，等他回码' : '已生成，点「复制」发给对方', ok ? 'ok' : '');
        }).catch(function (e) {
          setCodeHint('生成失败：' + (e.message || e), 'err');
        }).then(function () { netBusy = false; });
        return;
      }

      var kind = Net.classify(val);

      /* 对方发来的是房间码 → 我生成应答码 */
      if (kind === 'offer') {
        netBusy = true;
        setCodeHint('正在生成应答码…');
        Net.joinWith(val).then(function (ans) {
          box.value = ans;
          var ok = copyText(ans);
          updateCodeButton();
          setCodeHint(ok ? '已复制，发回给房主，等他连接' : '已生成，点「复制」发回给房主', ok ? 'ok' : '');
        }).catch(function (e) {
          setCodeHint('失败：' + (e.message || e), 'err');
        }).then(function () { netBusy = false; });
        return;
      }

      /* 对方发来的是应答码 → 完成连接 */
      if (kind === 'answer') {
        netBusy = true;
        setCodeHint('正在连接…');
        Net.acceptCode(val).then(function () {
          setCodeHint('已连上，正在建立通道…', 'ok');
        }).catch(function (e) {
          setCodeHint('连接失败：' + (e.message || e), 'err');
        }).then(function () { netBusy = false; });
        return;
      }

      setCodeHint('这段码看不懂，让对方点「复制」再发一次完整的', 'err');
    }

    $('btnCodeAction').addEventListener('click', codeAction);
    $('btnCodeCopy').addEventListener('click', function () {
      var ok = copyText(($('codeBox').value || '').trim());
      setCodeHint(ok ? '已复制' : '复制失败，长按输入框手动全选', ok ? 'ok' : 'err');
    });
    $('codeBox').addEventListener('input', updateCodeButton);
  }

  /* ---------------- 事件绑定 ---------------- */
  function bind() {
    $('btnFold').addEventListener('click', function () { doAction({ type: 'fold' }); });

    $('btnCall').addEventListener('click', function () {
      if (!heroTurnActive) return;
      var lg = currentLegal();
      doAction({ type: lg && lg.canCheck ? 'check' : 'call' });
    });

    $('btnRaise').addEventListener('click', function () {
      if (!heroTurnActive) return;
      doAction({ type: 'raise', amount: Number($('raiseSlider').value) });
    });

    var slider = $('raiseSlider');
    slider.addEventListener('input', function () { $('raiseVal').textContent = slider.value; });

    var chips = document.querySelectorAll('.chip-btn');
    for (var i = 0; i < chips.length; i++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          if (!heroTurnActive) return;
          var lg = currentLegal();
          if (!lg) return;
          var frac = btn.getAttribute('data-frac');
          var target;
          if (frac === 'allin') target = lg.maxRaiseTo;
          else target = (lastState ? lastState.currentBet : 0) + Math.round(lg.pot * Number(frac) / 5) * 5;
          target = Math.max(lg.minRaiseTo, Math.min(lg.maxRaiseTo, target));
          slider.value = target;
          $('raiseVal').textContent = target;
        });
      })(chips[i]);
    }

    $('btnNext').addEventListener('click', function () {
      if (netDropped) {
        netDropped = false;
        mode = 'lobby';
        hideBanner();
        hideActions(false);
        lastBannerKey = null;
        lastState = null;
        if (window.Net) Net.closeAll();
        showLobby();
        return;
      }
      if (mode === 'guest') return;
      hideBanner();
      lastBannerKey = null;
      if (!engine) return;
      if (engine.players[mySeat].chips <= 0) {
        engine.resetAll(2000, true);
        stats.hands = 0; stats.best = 0; saveStats();
      }
      engine.startHand();
      render();
      drive();
    });

    $('btnMenu').addEventListener('click', function () {
      setVisible('btnLeaveRoom', mode === 'host' || mode === 'guest');
      $('infoBlinds').textContent = '10 / 20';
      $('infoStart').textContent = '2000';
      $('infoHands').textContent = stats.hands;
      $('infoBest').textContent = stats.best;
      setDrawer(true);
    });
    $('btnCloseDrawer').addEventListener('click', function () { setDrawer(false); });
    $('drawer').addEventListener('click', function (e) { if (e.target === this) setDrawer(false); });

    $('btnLeaveRoom').addEventListener('click', function () { leaveRoom(); });

    $('chatBtn').addEventListener('click', function () {
      if ($('chatBar').classList.contains('hidden')) openChat();
      else closeChat();
    });
    $('chatFeed').addEventListener('click', openChat);
    $('chatSend').addEventListener('click', sendChat);
    $('chatInput').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); sendChat(); }
      if (e.key === 'Escape') closeChat();
    });

    $('btnSpeed').addEventListener('click', function () {
      speedLevel = (speedLevel + 1) % 3;
      $('btnSpeed').textContent = 'AI 速度：' + ['快', '标准', '慢'][speedLevel];
    });

    $('btnReset').addEventListener('click', function () {
      if (mode === 'guest') return setDrawer(false);
      if (!engine) return setDrawer(false);
      engine.resetAll(2000, true);
      stats.hands = 0; stats.best = 0; saveStats();
      setDrawer(false);
      hideBanner();
      lastBannerKey = null;
      engine.startHand();
      render();
      drive();
    });

    var segs = document.querySelectorAll('#diffSeg .seg-btn');
    for (var s2 = 0; s2 < segs.length; s2++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          applyDifficulty(btn.getAttribute('data-diff'), true);
        });
      })(segs[s2]);
    }

    /* 大厅 */
    $('btnSolo').addEventListener('click', enterSolo);
    $('btnToNet').addEventListener('click', showNetPanel);
    $('btnAdvanced').addEventListener('click', function () {
      var box = $('advancedBox');
      var open = box.classList.contains('hidden');
      setVisible(box, open);
      if (open) {
        var cb = $('codeBox');
        if (cb) cb.value = '';
        var ab = $('btnCodeAction');
        if (ab) ab.textContent = '生成我的连接码';
      }
      $('btnAdvanced').textContent = open ? '收起连接码模式 ▴' : '连不上服务器？改用连接码模式 ▾';
    });

    $('btnBackLobby').addEventListener('click', function () {
      setVisible('netPanel', false);
      setVisible('lobby', true);
    });

    var roles = document.querySelectorAll('#roleSeg .seg-btn');
    for (var r = 0; r < roles.length; r++) {
      (function (btn) {
        btn.addEventListener('click', function () {
          netRole = btn.getAttribute('data-role');
          for (var j = 0; j < roles.length; j++) {
            if (roles[j] === btn) roles[j].classList.add('active');
            else roles[j].classList.remove('active');
          }
          if (netRole === 'host') {
            setVisible('hostBox', true);
            setVisible('guestBox', false);
          } else {
            setVisible('hostBox', false);
            setVisible('guestBox', true);
          }
          setVisible('lanHostBox', netRole === 'host');
          setVisible('lanJoinBox', netRole === 'guest');
          setNetStatus('两台手机需要连同一个 WiFi', '');
        });
      })(roles[r]);
    }
  }

  function currentLegal() {
    if (lastState && lastState.legal) return lastState.legal;
    if (engine && engine.inHand && engine.actor >= 0) return engine.legal(engine.actor);
    return null;
  }

  /* ---------------- 启动 ---------------- */
  function boot() {
    syncViewport();
    window.addEventListener('resize', syncViewport);
    window.addEventListener('orientationchange', function () { setTimeout(syncViewport, 120); });
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', function () {
        syncViewport();
        // 软键盘弹出时，把聊天面板抬到键盘上方
        var vv = window.visualViewport;
        var kb = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
        document.documentElement.style.setProperty('--kb', Math.round(kb) + 'px');
      });
    }

    loadStats();
    loadDifficulty();
    applyDifficulty(difficulty, false);
    setDrawer(false);
    setVisible('banner', false);
    bind();
    bindNet();

    if (!window.Net || !Net.supported()) {
      $('btnToNet').disabled = true;
      $('netStatus').textContent = '当前浏览器不支持点对点直连';
    }
    showLobby();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
