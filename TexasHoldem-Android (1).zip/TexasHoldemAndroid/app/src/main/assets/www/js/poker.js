/* ==========================================================
 * poker.js —— 牌与牌型判定（纯逻辑，无 DOM 依赖）
 * 牌面表示：'A s' -> "As"，rank 取字符，suit 取第二字符
 * ========================================================== */
(function (global) {
  'use strict';

  var RANK_STR = '23456789TJQKA';           // 2..A
  var SUITS = ['s', 'h', 'd', 'c'];
  var SUIT_SYMBOL = { s: '\u2660', h: '\u2665', d: '\u2666', c: '\u2663' };
  var RANK_LABEL = { 11: 'J', 12: 'Q', 13: 'K', 14: 'A' };

  var CAT_NAMES = ['高牌', '一对', '两对', '三条', '顺子', '同花', '葫芦', '四条', '同花顺'];

  function rankOf(card) { return RANK_STR.indexOf(card.charAt(0)) + 2; }
  function suitOf(card) { return card.charAt(1); }
  function rankLabel(r) { return RANK_LABEL[r] || String(r); }

  function makeDeck() {
    var d = [];
    for (var i = 0; i < SUITS.length; i++) {
      for (var j = 0; j < RANK_STR.length; j++) d.push(RANK_STR.charAt(j) + SUITS[i]);
    }
    return d;
  }

  function shuffle(arr) {
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
    return arr;
  }

  /* 返回顺子的最高张点数（A 可作 1 组成 A2345），无顺子返回 0 */
  function straightHighTop(ranksDesc) {
    var set = {};
    for (var i = 0; i < ranksDesc.length; i++) set[ranksDesc[i]] = true;
    if (set[14]) set[1] = true;
    var arr = [];
    for (var k in set) if (set.hasOwnProperty(k)) arr.push(Number(k));
    arr.sort(function (a, b) { return b - a; });
    for (var m = 0; m + 4 < arr.length; m++) {
      if (arr[m] - arr[m + 4] === 4) return arr[m];
    }
    return 0;
  }

  var _seq = 0;
  function mk(cat, kickers) {
    var powers = [1e8, 1e6, 1e4, 1e2, 1];
    var score = cat * 1e10;
    for (var i = 0; i < 5; i++) score += (kickers[i] || 0) * powers[i];
    var name = CAT_NAMES[cat];
    if (cat === 8 && kickers[0] === 14) name = '皇家同花顺';
    return { score: score, cat: cat, kickers: kickers, name: name, seq: _seq++ };
  }

  /* 7 张选 5 张的最优牌型 */
  function evaluate7(cards) {
    var cnt = {}, suitCards = { s: [], h: [], d: [], c: [] };
    for (var i = 0; i < cards.length; i++) {
      var r = rankOf(cards[i]);
      cnt[r] = (cnt[r] || 0) + 1;
      suitCards[suitOf(cards[i])].push(r);
    }
    var ranksDesc = Object.keys(cnt).map(Number).sort(function (a, b) { return b - a; });
    var byCount = {};
    for (var a = 0; a < ranksDesc.length; a++) {
      var rr = ranksDesc[a], n = cnt[rr];
      (byCount[n] = byCount[n] || []).push(rr);
    }

    var flushSuit = null;
    for (var s = 0; s < SUITS.length; s++) if (suitCards[SUITS[s]].length >= 5) { flushSuit = SUITS[s]; break; }

    if (flushSuit) {
      var frAll = suitCards[flushSuit].slice().sort(function (x, y) { return y - x; });
      var sfTop = straightHighTop(frAll);
      if (sfTop) return mk(8, [sfTop]);
    }
    if (byCount[4]) {
      var q = byCount[4][0];
      var qk = ranksDesc.filter(function (x) { return x !== q; })[0];
      return mk(7, [q, qk]);
    }
    if (byCount[3] && (byCount[3].length > 1 || byCount[2])) {
      var t3 = byCount[3][0];
      var second = byCount[3].length > 1 ? byCount[3][1] : byCount[2][0];
      return mk(6, [t3, second]);
    }
    if (flushSuit) {
      var fr = suitCards[flushSuit].slice().sort(function (x, y) { return y - x; }).slice(0, 5);
      return mk(5, fr);
    }
    var stTop = straightHighTop(ranksDesc);
    if (stTop) return mk(4, [stTop]);

    if (byCount[3]) {
      var t = byCount[3][0];
      var kick2 = ranksDesc.filter(function (x) { return x !== t; }).slice(0, 2);
      return mk(3, [t].concat(kick2));
    }
    if (byCount[2] && byCount[2].length >= 2) {
      var p1 = byCount[2][0], p2 = byCount[2][1];
      var k1 = ranksDesc.filter(function (x) { return x !== p1 && x !== p2; })[0];
      return mk(2, [p1, p2, k1]);
    }
    if (byCount[2]) {
      var p = byCount[2][0];
      var kick3 = ranksDesc.filter(function (x) { return x !== p; }).slice(0, 3);
      return mk(1, [p].concat(kick3));
    }
    return mk(0, ranksDesc.slice(0, 5));
  }

  /* 多手牌比较：返回分数最高的下标数组（可能并列） */
  function winners(hands) {
    var best = -1, out = [];
    for (var i = 0; i < hands.length; i++) {
      var sc = hands[i].score;
      if (sc > best) { best = sc; out = [i]; }
      else if (sc === best) out.push(i);
    }
    return out;
  }

  var API = {
    RANK_STR: RANK_STR, SUITS: SUITS, SUIT_SYMBOL: SUIT_SYMBOL, CAT_NAMES: CAT_NAMES,
    rankOf: rankOf, suitOf: suitOf, rankLabel: rankLabel,
    makeDeck: makeDeck, shuffle: shuffle,
    evaluate7: evaluate7, winners: winners
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  global.Poker = API;
})(typeof window !== 'undefined' ? window : globalThis);
