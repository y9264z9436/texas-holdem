/* ==========================================================
 * net.js —— 联机传输层
 *
 * 模式一（默认）：房间号 + 公共信令服务器（PeerJS）
 *   进房只需输入 4 位数字，天然支持多人（所有人都连房主）
 *   缺点：需要手机能访问 0.peerjs.com
 *
 * 模式二（兜底）：连接码 + 纯 WebRTC（手动复制粘贴）
 *   完全离线，但只能 1v1，且要互相发一段长码
 * ========================================================== */
(function (global) {
  'use strict';

  var handlers = {};
  var conns = {};          // 房主侧：seat -> DataConnection
  var hostConn = null;     // 客机侧：与房主的连接
  var peer = null;
  var nextSeat = 1;
  var accepting = true;      // 房主是否还接收新玩家（开局后置 false）

  /* ---------- 局域网直连（原生 TCP，走 Android 桥） ---------- */
  var LAN_PORT = 9528;
  var lanMode = null;        // 'host' | 'guest' | null
  var lanSeats = {};         // 房主侧已知座位
  var lanSinkReady = false;
  var lanOnOpen = null;
  var legacyPc = null;
  var legacyDc = null;

  function emit(ev, a, b) {
    var arr = handlers[ev] || [];
    for (var i = 0; i < arr.length; i++) {
      try { arr[i](a, b); } catch (e) { }
    }
  }

  function b64e(s) { return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function b64d(s) {
    s = String(s || '').replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    return atob(s);
  }

  var ROOM_PREFIX = 'thp2026-';

  /* 同一 WiFi 时靠内网直连，这些 STUN 只在「一个连 WiFi 一个用流量」时才用得上 */
  var ICE = {
    iceServers: [
      { urls: 'stun:stun.cloudflare.com:3478' },
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' }
    ]
  };

  function newPeer(id) {
    var opts = { debug: 0, config: ICE };
    if (id) opts.id = id;
    return new global.Peer(id || undefined, opts);
  }

  function randomRoom() {
    return String(Math.floor(1000 + Math.random() * 9000));
  }

  function ensureLanSink() {
    if (lanSinkReady) return;
    lanSinkReady = true;
    global.__lanEvent = function (raw) {
      var m = raw;
      if (typeof raw === 'string') {
        try { m = JSON.parse(raw); } catch (e) { return; }
      }
      if (!m || !m.ev) return;
      if (m.ev === 'peer-join') {
        lanSeats[m.seat] = true;
        emit('peer-join', m.seat);
      } else if (m.ev === 'peer-left') {
        delete lanSeats[m.seat];
        emit('peer-left', m.seat);
      } else if (m.ev === 'message') {
        emit('message', m.data, m.seat);
      } else if (m.ev === 'connected') {
        emit('open');
        if (lanOnOpen) { var f = lanOnOpen; lanOnOpen = null; f(); }
      } else if (m.ev === 'closed') {
        emit('close');
      } else if (m.ev === 'error') {
        emit('lan-error', m.msg || '局域网出错');
      }
    };
  }

  var API = {
    lanSupported: function () { return !!global.LanBridge; },

    /* 房主：开房间，返回本机 IP */
    hostLan: function (port) {
      return new Promise(function (resolve, reject) {
        if (!global.LanBridge) return reject(new Error('局域网模式只能在 APP 里用'));
        ensureLanSink();
        lanMode = 'host';
        lanSeats = {};
        var ip = global.LanBridge.start(port || LAN_PORT);
        if (!ip) {
          lanMode = null;
          return reject(new Error('开启失败：端口可能被占用，或手机没连 WiFi'));
        }
        resolve(ip);
      });
    },

    /* 加入方：连房主的 IP */
    joinLan: function (ip, port) {
      return new Promise(function (resolve, reject) {
        if (!global.LanBridge) return reject(new Error('局域网模式只能在 APP 里用'));
        ensureLanSink();
        lanMode = 'guest';
        var done = false;
        var timer = setTimeout(function () {
          if (done) return;
          done = true; lanOnOpen = null;
          reject(new Error('连接超时：确认两台手机在同一个 WiFi，地址没输错'));
        }, 6000);
        lanOnOpen = function () {
          if (done) return;
          done = true; clearTimeout(timer);
          resolve();
        };
        try { global.LanBridge.connect(ip, port || LAN_PORT); }
        catch (e) { done = true; clearTimeout(timer); reject(e); }
      });
    },

    lanIp: function () { return global.LanBridge ? global.LanBridge.localIp() : ''; },

    lanSeatCount: function () { return Object.keys(lanSeats).length; },

    /* 房间号模式是否可用（依赖 PeerJS 库） */
    roomSupported: function () { return typeof global.Peer === 'function'; },
    codeSupported: function () { return typeof global.RTCPeerConnection === 'function'; },
    supported: function () { return API.roomSupported() || API.codeSupported(); },

    on: function (ev, fn) { (handlers[ev] = handlers[ev] || []).push(fn); return API; },

    /* 房主开局后关闸；重新建房时再打开 */
    setAccepting: function (v) { accepting = !!v; return accepting; },

    isSeatOpen: function (seat) {
      if (lanMode === 'host') return !!lanSeats[seat];
      var c = conns[seat];
      return !!c && c.open !== false;
    },
    hasSeat: function (seat) {
      if (lanMode === 'host') return !!lanSeats[seat];
      return !!conns[seat] && conns[seat].open !== false;
    },
    seatCount: function () {
      if (lanMode === 'host') return Object.keys(lanSeats).length;
      var n = 0;
      for (var k in conns) if (conns.hasOwnProperty(k)) n++;
      return n;
    },
    seats: function () {
      if (lanMode === 'host') {
        return Object.keys(lanSeats).map(Number).sort(function (a, b) { return a - b; });
      }
      var arr = [];
      for (var k in conns) if (conns.hasOwnProperty(k)) arr.push(Number(k));
      return arr.sort(function (a, b) { return a - b; });
    },

    /* ---------------- 模式一：房间号 ---------------- */
    hostRoom: function () {
      return new Promise(function (resolve, reject) {
        if (!API.roomSupported()) return reject(new Error('浏览器没有加载到联机组件'));

        function attempt(n, tried) {
          conns = {}; nextSeat = 1; accepting = true;
          try { if (peer) peer.destroy(); } catch (e) { }
          peer = null;

          var roomId = randomRoom();
          if (tried.indexOf(roomId) >= 0) roomId = randomRoom();
          tried.push(roomId);

          var settled = false;
          try { peer = newPeer(ROOM_PREFIX + roomId); } catch (e) { return reject(e); }

          var timer = setTimeout(function () {
            if (settled) return;
            settled = true;
            if (n < 3) return attempt(n + 1, tried);
            reject(new Error('连接服务器超时，可能是网络不通'));
          }, 9000);

          peer.on('open', function () {
            if (settled) return;
            settled = true; clearTimeout(timer);
            resolve(roomId);
          });

          peer.on('error', function (err) {
            var t = (err && err.type) || '';
            if (!settled) {
              if ((t === 'unavailable-id' || t === 'network' || t === 'server-error') && n < 3) {
                settled = true; clearTimeout(timer);
                setTimeout(function () { attempt(n + 1, tried); }, 800);
                return;
              }
              settled = true; clearTimeout(timer);
              if (t === 'network' || t === 'server-error') reject(new Error('连不上联机服务器，请改用连接码模式'));
              else reject(new Error('创建房间失败：' + t));
              return;
            }
            if (t === 'network' || t === 'server-error') emit('server-lost');
          });

          peer.on('connection', function (conn) {
            if (!accepting) {
              conn.on('open', function () {
                try { conn.send({ t: 'reject', reason: 'started' }); } catch (e) { }
                setTimeout(function () { try { conn.close(); } catch (e) { } }, 400);
              });
              return;
            }
            conn.on('open', function () {
              var seat = nextSeat++;
              conns[seat] = conn;
              conn.on('data', function (d) { emit('message', d, seat); });
              conn.on('close', function () { delete conns[seat]; emit('peer-left', seat); });
              conn.on('error', function () { });
              emit('peer-join', seat);
            });
          });

          peer.on('disconnected', function () {
            // 切后台/弱网导致掉线，尝试自己重连
            try { peer.reconnect(); } catch (e) { }
          });
        }

        attempt(1, []);
      });
    },

    joinRoom: function (roomId) {
      return new Promise(function (resolve, reject) {
        if (!API.roomSupported()) return reject(new Error('浏览器没有加载到联机组件'));

        function attempt(n) {
          try { if (peer) peer.destroy(); } catch (e) { }
          peer = null;
          var settled = false;
          try { peer = newPeer(); } catch (e) { return reject(e); }

          var timer = setTimeout(function () {
            if (settled) return;
            settled = true;
            if (n < 3) return attempt(n + 1);
            reject(new Error('连接超时：检查两台手机是否在同一网络，或让房主重新建房'));
          }, 10000);

          peer.on('error', function (err) {
            var t = (err && err.type) || '';
            if (settled) {
              if (t === 'network' || t === 'server-error') emit('server-lost');
              return;
            }
            if (t === 'peer-unavailable') {
              // 房间可能刚建、还没在服务器注册好 —— 等一会儿再试
              settled = true; clearTimeout(timer);
              if (n < 3) { setTimeout(function () { attempt(n + 1); }, 1200); return; }
              reject(new Error('找不到这个房间：确认房间号没错，且房主那边已经建好房间'));
              return;
            }
            if (t === 'network' || t === 'server-error') {
              settled = true; clearTimeout(timer);
              if (n < 2) { setTimeout(function () { attempt(n + 1); }, 1000); return; }
              reject(new Error('连不上联机服务器，请改用连接码模式'));
              return;
            }
            settled = true; clearTimeout(timer);
            reject(new Error('加入失败：' + t));
          });

          peer.on('open', function () {
            var conn = peer.connect(ROOM_PREFIX + roomId, { reliable: true });
            var connTimer = setTimeout(function () {
              if (settled) return;
              settled = true; clearTimeout(timer);
              if (n < 3) { attempt(n + 1); return; }
              reject(new Error('握手超时，可能在两个不同网络，建议连同一 WiFi'));
            }, 12000);

            conn.on('open', function () {
              clearTimeout(connTimer);
              hostConn = conn;
              conn.on('data', function (d) { emit('message', d, 0); });
              conn.on('close', function () { emit('close'); });
              if (!settled) { settled = true; clearTimeout(timer); resolve(); }
            });
            conn.on('error', function () { });
          });

          peer.on('disconnected', function () {
            try { peer.reconnect(); } catch (e) { }
          });
        }

        attempt(1);
      });
    },

    /* ---------------- 发送 ---------------- */
    sendTo: function (seat, obj) {
      if (lanMode === 'host' && global.LanBridge) {
        try { global.LanBridge.sendTo(seat, JSON.stringify(obj)); return true; } catch (e) { return false; }
      }
      var c = conns[seat];
      if (c && c.open !== false) { try { c.send(obj); return true; } catch (e) { return false; } }
      return false;
    },
    send: function (obj) {
      if (lanMode === 'guest' && global.LanBridge) {
        try { global.LanBridge.send(JSON.stringify(obj)); return true; } catch (e) { return false; }
      }
      if (hostConn && hostConn.open !== false) {
        try { hostConn.send(obj); return true; } catch (e) { return false; }
      }
      if (legacyDc && legacyDc.readyState === 'open') {
        try { legacyDc.send(JSON.stringify(obj)); return true; } catch (e) { return false; }
      }
      return false;
    },

    /* 判断一段码是「房间码(offer)」还是「应答码(answer)」 */
    classify: function (code) {
      var sdp;
      try { sdp = b64d(code); } catch (e) { return 'unknown'; }
      if (sdp.indexOf('v=0') !== 0) return 'unknown';
      if (sdp.indexOf('a=setup:actpass') >= 0) return 'offer';
      if (sdp.indexOf('a=setup:active') >= 0 || sdp.indexOf('a=setup:passive') >= 0) return 'answer';
      // 兜底：offer 里一定有 m=application，answer 也有；靠指纹判断
      return sdp.indexOf('a=ice-options') >= 0 ? 'offer' : 'answer';
    },

    /* ---------------- 模式二：连接码（纯 WebRTC，离线） ---------------- */
    createCode: function () {
      return new Promise(function (resolve, reject) {
        if (!API.codeSupported()) return reject(new Error('这个浏览器不支持点对点直连'));
        try {
          legacyPc = new RTCPeerConnection({ iceServers: [], iceCandidatePoolSize: 0 });
          legacyDc = legacyPc.createDataChannel('poker', { ordered: true });
          bindLegacy(legacyDc);
          legacyPc.createOffer()
            .then(function (o) { return legacyPc.setLocalDescription(o); })
            .then(function () { return waitIce(legacyPc); })
            .then(function () { resolve(b64e(legacyPc.localDescription.sdp)); })
            .catch(reject);
        } catch (e) { reject(e); }
      });
    },
    joinWith: function (code) {
      return new Promise(function (resolve, reject) {
        if (!API.codeSupported()) return reject(new Error('这个浏览器不支持点对点直连'));
        var sdp;
        try { sdp = b64d(code); } catch (e) { return reject(new Error('房间码格式不对')); }
        if (sdp.indexOf('v=0') !== 0) return reject(new Error('房间码内容无效'));
        try {
          legacyPc = new RTCPeerConnection({ iceServers: [], iceCandidatePoolSize: 0 });
          legacyPc.ondatachannel = function (e) { bindLegacy(e.channel); };
          legacyPc.setRemoteDescription({ type: 'offer', sdp: sdp })
            .then(function () { return legacyPc.createAnswer(); })
            .then(function (a) { return legacyPc.setLocalDescription(a); })
            .then(function () { return waitIce(legacyPc); })
            .then(function () { resolve(b64e(legacyPc.localDescription.sdp)); })
            .catch(reject);
        } catch (e) { reject(e); }
      });
    },
    acceptCode: function (code) {
      return new Promise(function (resolve, reject) {
        if (!legacyPc) return reject(new Error('还没生成房间码'));
        var sdp;
        try { sdp = b64d(code); } catch (e) { return reject(new Error('应答码格式不对')); }
        legacyPc.setRemoteDescription({ type: 'answer', sdp: sdp }).then(resolve).catch(reject);
      });
    },

    closeAll: function () {
      if (global.LanBridge) { try { global.LanBridge.stop(); } catch (e) { } }
      lanMode = null; lanSeats = {}; lanOnOpen = null;
      for (var k in conns) { try { conns[k].close(); } catch (e) { } }
      conns = {};
      try { if (hostConn) hostConn.close(); } catch (e) { }
      try { if (legacyDc) legacyDc.close(); } catch (e) { }
      try { if (legacyPc) legacyPc.close(); } catch (e) { }
      try { if (peer) peer.destroy(); } catch (e) { }
      peer = null; hostConn = null; legacyDc = null; legacyPc = null;
    }
  };

  function bindLegacy(dc) {
    legacyDc = dc;
    dc.onopen = function () { emit('open'); };
    dc.onclose = function () { emit('close'); };
    dc.onmessage = function (e) {
      var m = null;
      try { m = JSON.parse(e.data); } catch (err) { return; }
      emit('message', m, 0);
    };
  }

  function waitIce(p) {
    return new Promise(function (resolve) {
      if (p.iceGatheringState === 'complete') return resolve();
      var done = false;
      function fin() { if (done) return; done = true; resolve(); }
      p.addEventListener('icegatheringstatechange', function () {
        if (p.iceGatheringState === 'complete') fin();
      });
      setTimeout(fin, 2500);
    });
  }

  /* 手机切到微信再切回来时，WebSocket 常被系统挂断，这里自动救一次 */
  if (typeof document !== 'undefined' && document.addEventListener) {
    document.addEventListener('visibilitychange', function () {
      if (document.hidden || !peer) return;
      try {
        if (peer.disconnected && !peer.destroyed) peer.reconnect();
      } catch (e) { }
    });
  }

  global.Net = API;
})(typeof window !== 'undefined' ? window : globalThis);
