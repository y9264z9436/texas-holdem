package com.xiongda.texasholdem

import android.webkit.JavascriptInterface

/**
 * 暴露给网页的局域网接口（window.LanBridge）。
 * 所有方法都会被 JS 调用，注意不要在方法里做耗时阻塞（connect 已丢到子线程）。
 */
class LanBridge {

    /** 房主：开端口。成功返回本机局域网 IP，失败返回空串 */
    @JavascriptInterface
    fun start(port: Int): String {
        return if (Lan.start(port)) Lan.localIp() else ""
    }

    @JavascriptInterface
    fun stop() {
        Lan.stop()
        Lan.disconnect()
    }

    /** 加入方：连接房主。结果通过事件回调告知 */
    @JavascriptInterface
    fun connect(ip: String, port: Int) {
        val t = Thread { Lan.connect(ip, port) }
        t.isDaemon = true
        t.start()
    }

    @JavascriptInterface
    fun sendTo(seat: Int, text: String) {
        Lan.sendTo(seat, text)
    }

    @JavascriptInterface
    fun broadcast(text: String) {
        Lan.sendToAll(text)
    }

    @JavascriptInterface
    fun send(text: String) {
        Lan.sendToServer(text)
    }

    @JavascriptInterface
    fun localIp(): String = Lan.localIp()

    @JavascriptInterface
    fun clientCount(): Int = Lan.clientCount()

    @JavascriptInterface
    fun running(): Boolean = Lan.isRunning()
}
