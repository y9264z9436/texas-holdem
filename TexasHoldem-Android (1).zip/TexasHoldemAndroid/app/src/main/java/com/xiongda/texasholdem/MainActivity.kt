package com.xiongda.texasholdem

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat

/**
 * 唯一的 Activity：全屏 WebView 加载 assets/www 里的游戏。
 *
 * 为什么要用 WebViewAssetLoader 而不是 file:// ：
 *   WebRTC（联机对战）要求「安全上下文」，
 *   file:// 在 WebView 里不被视为安全源，点对点连接会直接失败。
 *   映射到 https://appassets.androidplatform.net/ 之后就是标准 https 源，
 *   WebRTC、localStorage、剪贴板全部正常工作。
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var lastBackPress = 0L

    private val startUrl = "https://appassets.androidplatform.net/assets/www/index.html"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyImmersive()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(0xFF061711.toInt())
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true          // 昵称、难度等本地记忆
                allowFileAccess = false           // 走 https 虚拟域名，不需要文件协议
                allowContentAccess = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                textZoom = 100
                mediaPlaybackRequiresUserGesture = true
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                // WebRTC 数据通道需要
                @Suppress("DEPRECATION")
                setGeolocationEnabled(false)
            }

            webViewClient = object : WebViewClientCompat() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }

                // 只允许在本地资源里跳转，别的一律拦掉
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val url = request.url.toString()
                    return !url.startsWith("https://appassets.androidplatform.net")
                }
            }

            // 局域网直连的原生接口（不用服务器）
            addJavascriptInterface(LanBridge(), "LanBridge")

            loadUrl(startUrl)
        }

        // 原生事件 → JS
        Lan.sink = { json: String ->
            runOnUiThread {
                try {
                    webView.evaluateJavascript(
                        "window.__lanEvent && window.__lanEvent(" + org.json.JSONObject.quote(json) + ")",
                        null
                    )
                } catch (e: Exception) {
                }
            }
        }

        setContentView(webView)
    }

    /** 沉浸式全屏：隐藏状态栏与导航栏 */
    private fun applyImmersive() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val now = System.currentTimeMillis()
        if (now - lastBackPress < 2000) {
            super.onBackPressed()
        } else {
            lastBackPress = now
            Toast.makeText(this, "再按一次退出", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
        webView.pauseTimers()
    }

    override fun onResume() {
        super.onResume()
        webView.resumeTimers()
        webView.onResume()
        applyImmersive()
    }

    override fun onDestroy() {
        Lan.sink = null
        Lan.stop()
        Lan.disconnect()
        webView.loadUrl("about:blank")
        webView.destroy()
        super.onDestroy()
    }
}
