package com.xiongda.texasholdem

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket

/**
 * 局域网直连：原生 TCP，不依赖任何服务器。
 *
 * 房主开一个 ServerSocket，每个加入者一条独立连接；
 * 消息用「一行一个 JSON」的格式收发，简单可靠。
 *
 * 线程模型：
 *   - 每个连接一个读线程
 *   - 所有事件通过 [sink] 抛给上层（MainActivity 负责转到 JS）
 */
object Lan {

    const val DEFAULT_PORT = 9528

    private val lock = Any()

    /* 房主侧 */
    private var serverSocket: ServerSocket? = null
    private var running = false
    private var nextSeat = 1
    private val clients = LinkedHashMap<Int, Client>()

    /* 加入方侧 */
    private var clientSocket: Socket? = null
    private var clientReader: BufferedReader? = null
    private var clientWriter: PrintWriter? = null

    /** 事件出口，由 MainActivity 注入 */
    var sink: ((String) -> Unit)? = null

    private fun emit(json: String) {
        sink?.invoke(json)
    }

    private fun esc(s: String?): String {
        return (s ?: "").replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ")
    }

    /* ---------------- 工具 ---------------- */

    /** 取本机在局域网里的 IPv4，取不到返回空串 */
    fun localIp(): String {
        try {
            val ifs = NetworkInterface.getNetworkInterfaces() ?: return ""
            while (ifs.hasMoreElements()) {
                val nif = ifs.nextElement() ?: continue
                try {
                    if (!nif.isUp || nif.isLoopback) continue
                } catch (e: Exception) {
                    continue
                }
                val addrs = nif.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        val ip = a.hostAddress ?: continue
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
        return ""
    }

    fun isRunning(): Boolean = synchronized(lock) { running }

    fun clientCount(): Int = synchronized(lock) { clients.size }

    /* ---------------- 房主 ---------------- */

    fun start(port: Int = DEFAULT_PORT): Boolean {
        synchronized(lock) {
            if (running) return true
            try {
                val ss = ServerSocket(port)
                serverSocket = ss
                running = true
                nextSeat = 1
                clients.clear()
            } catch (e: Exception) {
                emit("{\"ev\":\"error\",\"msg\":\"开端口失败：${esc(e.message)}\"}")
                return false
            }
        }

        val acceptThread = Thread {
            while (true) {
                val ss = synchronized(lock) { if (running) serverSocket else null } ?: break
                val socket = try {
                    ss.accept()
                } catch (e: Exception) {
                    break
                }
                val seat = synchronized(lock) {
                    val s = nextSeat
                    nextSeat += 1
                    s
                }
                val c = Client(seat, socket)
                synchronized(lock) { clients[seat] = c }
                c.start()
                emit("{\"ev\":\"peer-join\",\"seat\":$seat}")
            }
        }
        acceptThread.isDaemon = true
        acceptThread.start()
        return true
    }

    fun stop() {
        synchronized(lock) {
            running = false
            try { serverSocket?.close() } catch (e: Exception) { }
            serverSocket = null
            for (c in clients.values) c.close()
            clients.clear()
            try { clientSocket?.close() } catch (e: Exception) { }
            clientSocket = null
            clientReader = null
            clientWriter = null
        }
    }

    fun sendTo(seat: Int, text: String) {
        val c = synchronized(lock) { clients[seat] }
        c?.send(text)
    }

    fun sendToAll(text: String) {
        val list = synchronized(lock) { clients.values.toList() }
        for (c in list) c.send(text)
    }

    /* ---------------- 加入方 ---------------- */

    fun connect(ip: String, port: Int = DEFAULT_PORT, timeoutMs: Int = 5000): Boolean {
        try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(ip, port), timeoutMs)

            val reader = BufferedReader(InputStreamReader(s.getInputStream(), "UTF-8"))
            val writer = PrintWriter(OutputStreamWriter(s.getOutputStream(), "UTF-8"), true)
            synchronized(lock) {
                clientSocket = s
                clientReader = reader
                clientWriter = writer
            }

            val t = Thread {
                try {
                    var line: String? = reader.readLine()
                    while (line != null) {
                        if (line!!.isNotBlank()) {
                            emit("{\"ev\":\"message\",\"seat\":0,\"data\":$line}")
                        }
                        line = reader.readLine()
                    }
                } catch (e: Exception) {
                } finally {
                    synchronized(lock) {
                        try { clientSocket?.close() } catch (e: Exception) { }
                        clientSocket = null
                        clientReader = null
                    }
                    emit("{\"ev\":\"closed\"}")
                }
            }
            t.isDaemon = true
            t.start()

            emit("{\"ev\":\"connected\"}")
            return true
        } catch (e: Exception) {
            emit("{\"ev\":\"error\",\"msg\":\"连接失败：${esc(e.message)}\"}")
            return false
        }
    }

    fun sendToServer(text: String) {
        val w = synchronized(lock) { clientWriter }
        try { w?.println(text) } catch (e: Exception) { }
    }

    fun disconnect() {
        synchronized(lock) {
            try { clientSocket?.close() } catch (e: Exception) { }
            clientSocket = null
            clientReader = null
            clientWriter = null
        }
    }

    /* ---------------- 房主侧的单条连接 ---------------- */
    private class Client(val seat: Int, val socket: Socket) {
        private val reader: BufferedReader? = try {
            BufferedReader(InputStreamReader(socket.getInputStream(), "UTF-8"))
        } catch (e: Exception) { null }

        private val writer: PrintWriter? = try {
            PrintWriter(OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true)
        } catch (e: Exception) { null }

        fun start() {
            val t = Thread {
                try {
                    var line: String? = reader?.readLine()
                    while (line != null) {
                        if (line!!.isNotBlank()) {
                            emit("{\"ev\":\"message\",\"seat\":$seat,\"data\":$line}")
                        }
                        line = reader?.readLine()
                    }
                } catch (e: Exception) {
                } finally {
                    close()
                    synchronized(Lan.lock) { Lan.clients.remove(seat) }
                    emit("{\"ev\":\"peer-left\",\"seat\":$seat}")
                }
            }
            t.isDaemon = true
            t.start()
        }

        fun send(text: String) {
            try { writer?.println(text) } catch (e: Exception) { }
        }

        fun close() {
            try { socket.close() } catch (e: Exception) { }
        }
    }
}
